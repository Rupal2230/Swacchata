/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState, useRef, useEffect, useMemo } from 'react';
import { 
  Camera, 
  Upload, 
  CheckCircle2, 
  AlertTriangle, 
  XCircle, 
  Trash2, 
  MapPin, 
  Star,
  RefreshCw,
  Info,
  ChevronRight,
  ShieldCheck,
  LayoutDashboard,
  Activity,
  Search,
  Clock,
  Building2,
  BarChart3,
  TrendingUp,
  PieChart as PieChartIcon,
  Download,
  Calendar,
  Filter,
  UserPlus,
  LogOut,
  ChevronDown,
  Play,
  Pause,
  Settings2,
  Users,
  UserCog,
  UserMinus,
  Mail,
  Shield,
  MessageSquare,
  FileText,
  Send,
  CheckCircle,
  Clock3,
  ArrowRight,
  Plus,
  Sparkles,
  Eye,
  X,
  Bell,
  BellRing,
  Droplets,
  Trash
} from 'lucide-react';
import { motion, AnimatePresence } from 'motion/react';
import { 
  LineChart, 
  Line, 
  XAxis, 
  YAxis, 
  CartesianGrid, 
  Tooltip, 
  ResponsiveContainer, 
  BarChart, 
  Bar, 
  PieChart, 
  Pie, 
  Cell,
  AreaChart,
  Area
} from 'recharts';
import { analyzePostOfficeImage, AuditResult } from './services/geminiService';
import { auth, db } from './firebase';
import { handleFirestoreError, OperationType, ErrorBoundary } from './components/FirebaseHelpers';
import { 
  onAuthStateChanged, 
  signInWithPopup, 
  GoogleAuthProvider, 
  signOut,
  User as FirebaseUser
} from 'firebase/auth';
import { 
  doc, 
  getDoc, 
  setDoc, 
  serverTimestamp,
  collection,
  query,
  orderBy,
  onSnapshot,
  addDoc,
  Timestamp,
  limit,
  getDocFromServer,
  doc as firestoreDoc
} from 'firebase/firestore';

const DIVISIONS = [
  { id: 'amravati', name: 'Amravati Division', state: 'Maharashtra' },
  { id: 'nagpur', name: 'Nagpur Division', state: 'Maharashtra' },
  { id: 'akola', name: 'Akola Division', state: 'Maharashtra' },
  { id: 'pune', name: 'Pune Division', state: 'Maharashtra' },
  { id: 'mumbai', name: 'Mumbai Division', state: 'Maharashtra' },
];

const POST_OFFICES = [
  { id: 'amr-ho', name: 'Amravati H.O.', area: 'Shyam Chowk', type: 'Head Office', division: 'amravati' },
  { id: 'amr-camp', name: 'Amravati Camp', area: 'Camp Road', type: 'Sub Office', division: 'amravati' },
  { id: 'rajapeth', name: 'Rajapeth', area: 'Rajapeth', type: 'Sub Office', division: 'amravati' },
  { id: 'gadge-nagar', name: 'Gadge Nagar', area: 'Gadge Nagar', type: 'Sub Office', division: 'amravati' },
  { id: 'badnera', name: 'Badnera', area: 'Badnera', type: 'Sub Office', division: 'amravati' },
  { id: 'rukmini', name: 'Rukmini Nagar', area: 'Rukmini Nagar', type: 'Sub Office', division: 'amravati' },
  { id: 'sai-nagar', name: 'Sai Nagar', area: 'Sai Nagar', type: 'Sub Office', division: 'amravati' },
  { id: 'irwin', name: 'Irwin Hospital', area: 'Morshi Road', type: 'Sub Office', division: 'amravati' },
  // Nagpur
  { id: 'ngp-ho', name: 'Nagpur G.P.O.', area: 'Civil Lines', type: 'Head Office', division: 'nagpur' },
  { id: 'ngp-itwari', name: 'Itwari S.O.', area: 'Itwari', type: 'Sub Office', division: 'nagpur' },
  { id: 'ngp-sitabuldi', name: 'Sitabuldi S.O.', area: 'Sitabuldi', type: 'Sub Office', division: 'nagpur' },
  // Akola
  { id: 'akl-ho', name: 'Akola H.O.', area: 'Main Road', type: 'Head Office', division: 'akola' },
  { id: 'akl-murtizapur', name: 'Murtizapur S.O.', area: 'Murtizapur', type: 'Sub Office', division: 'akola' },
  // Pune
  { id: 'pune-ho', name: 'Pune G.P.O.', area: 'Sadhu Vaswani Road', type: 'Head Office', division: 'pune' },
  { id: 'pune-city', name: 'Pune City S.O.', area: 'Budhwar Peth', type: 'Sub Office', division: 'pune' },
  // Mumbai
  { id: 'mumbai-gpo', name: 'Mumbai G.P.O.', area: 'Fort', type: 'Head Office', division: 'mumbai' },
  { id: 'mumbai-central', name: 'Mumbai Central', area: 'Tardeo', type: 'Sub Office', division: 'mumbai' },
];

const resizeImage = (base64Str: string, maxWidth = 800, maxHeight = 800): Promise<string> => {
  return new Promise((resolve) => {
    const img = new Image();
    img.src = base64Str;
    img.onload = () => {
      const canvas = document.createElement('canvas');
      let width = img.width;
      let height = img.height;

      if (width > height) {
        if (width > maxWidth) {
          height *= maxWidth / width;
          width = maxWidth;
        }
      } else {
        if (height > maxHeight) {
          width *= maxHeight / height;
          height = maxHeight;
        }
      }

      canvas.width = width;
      canvas.height = height;
      const ctx = canvas.getContext('2d');
      ctx?.drawImage(img, 0, 0, width, height);
      resolve(canvas.toDataURL('image/jpeg', 0.7));
    };
  });
};

export default function App() {
  const [user, setUser] = useState<FirebaseUser | null>(null);
  const [userProfile, setUserProfile] = useState<{ 
    role: 'admin' | 'worker' | 'user'; 
    notificationPreferences?: {
      garbage: boolean;
      water: boolean;
      overflow: boolean;
      complaints: boolean;
    };
  } | null>(null);
  const [isAuthLoading, setIsAuthLoading] = useState(true);
  const [showSplash, setShowSplash] = useState(true);
  const [showRoleSelection, setShowRoleSelection] = useState(false);

  const [activeTab, setActiveTab] = useState<'audit' | 'dashboard' | 'analytics' | 'users' | 'reports'>('dashboard');
  const [selectedDivisionId, setSelectedDivisionId] = useState('amravati');
  const [showDivisionSelector, setShowDivisionSelector] = useState(false);

  const currentDivision = useMemo(() => DIVISIONS.find(d => d.id === selectedDivisionId) || DIVISIONS[0], [selectedDivisionId]);
  const filteredPostOffices = useMemo(() => POST_OFFICES.filter(po => po.division === selectedDivisionId), [selectedDivisionId]);

  const [showUserMenu, setShowUserMenu] = useState(false);
  const [viewingLiveFeed, setViewingLiveFeed] = useState<string | null>(null);
  const [isFeedPaused, setIsFeedPaused] = useState(false);
  const [feedQuality, setFeedQuality] = useState<'720p' | '1080p' | '4K'>('720p');
  const [liveDetections, setLiveDetections] = useState<any[]>([]);

  // Simulate Live AI Detections
  useEffect(() => {
    if (!viewingLiveFeed || isFeedPaused) {
      setLiveDetections([]);
      return;
    }

    const interval = setInterval(() => {
      const possibleDetections = [
        { label: 'Garbage Detected', type: 'garbage', color: 'rose' },
        { label: 'Water Saturation', type: 'water', color: 'blue' },
        { label: 'Bin Overflowing', type: 'overflow', color: 'amber' }
      ];

      if (Math.random() > 0.7) {
        const detection = possibleDetections[Math.floor(Math.random() * possibleDetections.length)];
        const newDetection = {
          id: Date.now(),
          ...detection,
          x: Math.random() * 70 + 15, 
          y: Math.random() * 50 + 25, 
          width: Math.random() * 10 + 15,
          height: Math.random() * 10 + 15
        };
        setLiveDetections(prev => [...prev, newDetection].slice(-3));
      } else if (Math.random() > 0.8) {
        setLiveDetections(prev => prev.slice(1));
      }
    }, 3000);

    return () => clearInterval(interval);
  }, [viewingLiveFeed, isFeedPaused]);
  const [selectedLocation, setSelectedLocation] = useState(filteredPostOffices[0] || POST_OFFICES[0]);

  useEffect(() => {
    if (filteredPostOffices.length > 0) {
      setSelectedLocation(filteredPostOffices[0]);
    }
  }, [selectedDivisionId, filteredPostOffices]);

  const [image, setImage] = useState<string | null>(null);
  const [video, setVideo] = useState<string | null>(null);
  const [documentFile, setDocumentFile] = useState<string | null>(null);
  const [isAnalyzing, setIsAnalyzing] = useState(false);
  const [result, setResult] = useState<AuditResult | null>(null);
  const [error, setError] = useState<string | null>(null);
  const [audits, setAudits] = useState<any[]>([]);
  const [complaints, setComplaints] = useState<any[]>([]);
  const [allUsers, setAllUsers] = useState<any[]>([]);
  const [isUsersLoading, setIsUsersLoading] = useState(false);
  const [isSubmittingComplaint, setIsSubmittingComplaint] = useState(false);
  const [complaintDescription, setComplaintDescription] = useState('');
  const [resolvingComplaint, setResolvingComplaint] = useState<any | null>(null);
  const [afterImage, setAfterImage] = useState<string | null>(null);
  const [isResolving, setIsResolving] = useState(false);
  const [isCleanupMode, setIsCleanupMode] = useState(false);
  const [beforeImage, setBeforeImage] = useState<string | null>(null);
  const [isLoggingCleanup, setIsLoggingCleanup] = useState(false);
  const [showAddUserModal, setShowAddUserModal] = useState(false);
  const [newUserEmail, setNewUserEmail] = useState('');
  const [newUserName, setNewUserName] = useState('');
  const [newUserRole, setNewUserRole] = useState<'admin' | 'worker' | 'user'>('user');
  const [showQuickReport, setShowQuickReport] = useState(false);
  const fileInputRef = useRef<HTMLInputElement>(null);

  const [analyticsFilter, setAnalyticsFilter] = useState('All Locations');
  const [reportView, setReportView] = useState<'complaints' | 'reviews' | 'multimedia'>('complaints');
  const [selectedComplaint, setSelectedComplaint] = useState<any | null>(null);
  const [showNotifications, setShowNotifications] = useState(false);
  const [notifications, setNotifications] = useState<any[]>([]);
  const [isAnalyzingAI, setIsAnalyzingAI] = useState(false);
  const [showSettings, setShowSettings] = useState(false);

  // Mock Analytics Data
  const trendData = [
    { name: 'Mon', score: 3.8, prevScore: 3.5 },
    { name: 'Tue', score: 4.1, prevScore: 3.7 },
    { name: 'Wed', score: 3.9, prevScore: 4.0 },
    { name: 'Thu', score: 4.4, prevScore: 3.8 },
    { name: 'Fri', score: 4.2, prevScore: 4.1 },
    { name: 'Sat', score: 4.5, prevScore: 4.2 },
    { name: 'Sun', score: 4.3, prevScore: 4.0 },
  ];

  const issueData = [
    { name: 'Litter', value: 45, color: '#f43f5e' },
    { name: 'Infrastructure', value: 25, color: '#f59e0b' },
    { name: 'Maintenance', value: 30, color: '#3b82f6' },
  ];

  const performanceData = filteredPostOffices.map(po => {
    const poAudits = audits.filter(a => a.location === po.name);
    const avgScore = poAudits.length > 0 
      ? poAudits.reduce((acc, curr) => acc + curr.score, 0) / poAudits.length 
      : (Math.random() * 1.5 + 3.5);
    
    return {
      name: po.name,
      score: avgScore.toFixed(1)
    };
  }).sort((a, b) => Number(b.score) - Number(a.score));

  const detailedReports = audits.length > 0 ? audits : [
    { id: 'R1', date: '2026-03-13', location: filteredPostOffices[0]?.name || 'Main H.O.', score: 4.8, status: 'Excellent', issues: 0, verified: true },
    { id: 'R2', date: '2026-03-13', location: filteredPostOffices[1]?.name || 'Sub Office 1', score: 3.2, status: 'Needs Attention', issues: 2, verified: true },
    { id: 'R3', date: '2026-03-12', location: filteredPostOffices[2]?.name || 'Sub Office 2', score: 4.5, status: 'Excellent', issues: 0, verified: true },
  ];

  const exportReport = () => {
    const csvContent = "data:text/csv;charset=utf-8," 
      + "Date,Location,Score,Status,Issues,Verified\n"
      + detailedReports.map(r => `${r.date},${r.location},${r.score},${r.status},${r.issues},${r.verified}`).join("\n");
    
    const encodedUri = encodeURI(csvContent);
    const link = document.createElement("a");
    link.setAttribute("href", encodedUri);
    link.setAttribute("download", `Swachhata_Report_${new Date().toISOString().split('T')[0]}.csv`);
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
  };

  // Update timestamps periodically
  useEffect(() => {
    const timer = setTimeout(() => {
      setShowSplash(false);
    }, 1500);
    return () => clearTimeout(timer);
  }, []);

  useEffect(() => {
    const unsubscribe = onAuthStateChanged(auth, async (currentUser) => {
      try {
        setUser(currentUser);
        if (currentUser) {
          const docRef = doc(db, 'users', currentUser.uid);
          const docSnap = await getDoc(docRef);
          if (docSnap.exists()) {
            setUserProfile(docSnap.data() as any);
            setShowRoleSelection(false);
          } else {
            setShowRoleSelection(true);
          }
        } else {
          setUserProfile(null);
          setShowRoleSelection(false);
        }
      } catch (err) {
        console.error("Auth state change error:", err);
        setError("Failed to load user profile. Please try refreshing.");
      } finally {
        setIsAuthLoading(false);
      }
    });

    return () => unsubscribe();
  }, []);

  // Fetch real audits from Firestore
  useEffect(() => {
    if (!user) return;

    // Test connection
    const testConnection = async () => {
      try {
        await getDocFromServer(firestoreDoc(db, 'test', 'connection'));
      } catch (error) {
        if (error instanceof Error && error.message.includes('the client is offline')) {
          console.error("Please check your Firebase configuration.");
        }
      }
    };
    testConnection();

    const q = query(collection(db, 'audits'), orderBy('date', 'desc'), limit(50));
    const unsubscribe = onSnapshot(q, (snapshot) => {
      const auditData = snapshot.docs.map(doc => ({
        id: doc.id,
        ...doc.data(),
        date: doc.data().date?.toDate?.()?.toISOString()?.split('T')[0] || new Date().toISOString().split('T')[0]
      }));
      setAudits(auditData);
    }, (err) => {
      handleFirestoreError(err, OperationType.LIST, 'audits');
    });

    return () => unsubscribe();
  }, [user]);

  // Fetch all users for admins
  useEffect(() => {
    if (userProfile?.role !== 'admin') {
      setAllUsers([]);
      return;
    }

    setIsUsersLoading(true);
    const q = query(collection(db, 'users'), orderBy('createdAt', 'desc'));
    const unsubscribe = onSnapshot(q, (snapshot) => {
      const userData = snapshot.docs.map(doc => ({
        id: doc.id,
        ...doc.data()
      }));
      setAllUsers(userData);
      setIsUsersLoading(false);
    }, (err) => {
      handleFirestoreError(err, OperationType.LIST, 'users');
      setIsUsersLoading(false);
    });

    return () => unsubscribe();
  }, [userProfile]);

  // Fetch notifications
  useEffect(() => {
    if (!user) return;
    const q = query(collection(db, 'notifications'), orderBy('timestamp', 'desc'), limit(20));
    const unsubscribe = onSnapshot(q, (snapshot) => {
      const notifData = snapshot.docs.map(doc => ({
        id: doc.id,
        ...doc.data(),
        time: doc.data().timestamp?.toDate?.()?.toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }) || 'Just now'
      }));
      setNotifications(notifData);
    }, (err) => {
      handleFirestoreError(err, OperationType.LIST, 'notifications');
    });
    return () => unsubscribe();
  }, [user]);

  const triggerAIScan = async (locationId: string) => {
    if (isAnalyzingAI) return;
    setIsAnalyzingAI(true);
    
    try {
      const location = filteredPostOffices.find(po => po.id === locationId) || POST_OFFICES.find(po => po.id === locationId);
      if (!location) return;

      // Simulate AI processing delay
      await new Promise(resolve => setTimeout(resolve, 3000));

      // Randomly detect an issue (60% chance for simulation)
      const detectIssue = Math.random() > 0.4;
      
      if (detectIssue) {
        const rand = Math.random();
        const issueType = rand > 0.66 ? 'garbage' : rand > 0.33 ? 'water' : 'overflow';
        const title = issueType === 'garbage' ? 'Garbage Detected' : 
                      issueType === 'water' ? 'Saturated Water' : 'Bins Overflowing';
        
        // 1. Create Audit Record Automatically
        const auditData = {
          date: serverTimestamp(),
          location: location.name,
          score: issueType === 'garbage' ? 2.5 : issueType === 'water' ? 3.0 : 2.0,
          status: 'Needs Attention',
          issues: 1,
          verified: false,
          authorUid: 'system_ai',
          imageUrl: `https://picsum.photos/seed/ai-${locationId}-${Date.now()}/800/600`,
          timestamp: serverTimestamp(),
          isCleanupLog: false
        };
        await addDoc(collection(db, 'audits'), auditData);

        // 2. Create Notification
        const notifData = {
          type: 'ai_detection',
          issueType: issueType,
          title: title,
          location: location.name,
          message: `AI detected ${title.toLowerCase()} at ${location.name}. Immediate cleanup required.`,
          timestamp: serverTimestamp(),
          restricted: true,
          readBy: []
        };
        await addDoc(collection(db, 'notifications'), notifData);
        
        alert(`AI Scan Complete: ${title} found at ${location.name}! Audit record created.`);
      } else {
        alert("AI Scan Complete: No issues detected. Area is clean.");
      }
    } catch (err) {
      console.error("AI Scan error:", err);
      alert("AI Scan failed. Please try again.");
    } finally {
      setIsAnalyzingAI(false);
    }
  };

  const updateNotificationPreferences = async (prefs: any) => {
    if (!user) return;
    try {
      await setDoc(doc(db, 'users', user.uid), { 
        notificationPreferences: prefs 
      }, { merge: true });
      setUserProfile(prev => prev ? { ...prev, notificationPreferences: prefs } : null);
    } catch (err) {
      handleFirestoreError(err, OperationType.UPDATE, `users/${user.uid}`);
    }
  };

  const getNotifIcon = (type: string, issueType?: string) => {
    switch (type) {
      case 'ai_detection':
        if (issueType === 'water') return Droplets;
        if (issueType === 'overflow') return Trash2;
        return Trash;
      case 'complaint':
        return MessageSquare;
      case 'review':
        return CheckCircle2;
      default:
        return Bell;
    }
  };

  const getNotifColor = (type: string) => {
    switch (type) {
      case 'ai_detection': return 'text-rose-600 bg-rose-50';
      case 'complaint': return 'text-amber-600 bg-amber-50';
      case 'review': return 'text-emerald-600 bg-emerald-50';
      default: return 'text-blue-600 bg-blue-50';
    }
  };

  // Fetch complaints
  useEffect(() => {
    if (!user) return;

    const q = query(collection(db, 'complaints'), orderBy('date', 'desc'));
    const unsubscribe = onSnapshot(q, (snapshot) => {
      const complaintData = snapshot.docs.map(doc => ({
        id: doc.id,
        ...doc.data()
      }));
      setComplaints(complaintData);
    }, (err) => {
      handleFirestoreError(err, OperationType.LIST, 'complaints');
    });

    return () => unsubscribe();
  }, [user]);

  // Combine citizen complaints and AI-detected issues for workers/admins
  const combinedReports = useMemo(() => {
    const aiAudits = audits
      .filter(a => a.authorUid === 'system_ai' && !a.isCleanupLog)
      .map(a => ({
        ...a,
        description: a.summary || `AI detected an issue at ${a.location}. Immediate cleanup required.`,
        authorName: 'AI Swachhata Monitor',
        isAI: true,
        imageUrl: a.imageUrl || null,
        status: (a.status === 'Excellent' || a.status === 'Optimal' || a.status === 'resolved') ? 'resolved' : 'pending'
      }));
    
    return [...complaints, ...aiAudits].sort((a, b) => {
      const dateA = a.date?.toDate?.() || new Date(0);
      const dateB = b.date?.toDate?.() || new Date(0);
      return dateB.getTime() - dateA.getTime();
    });
  }, [complaints, audits]);

  // Derived dashboard data from real audits
  const dashboardData = filteredPostOffices.map(po => {
    const poAudits = audits.filter(a => a.location === po.name);
    const latestAudit = poAudits[0];
    
    return {
      ...po,
      score: latestAudit ? latestAudit.score.toFixed(1) : (Math.random() * 2 + 3).toFixed(1),
      status: latestAudit ? (latestAudit.score >= 4 ? 'Clean' : 'Needs Attention') : (Math.random() > 0.3 ? 'Clean' : 'Needs Attention'),
      lastAudit: latestAudit ? 'Updated recently' : 'No recent audits',
      activeAlerts: latestAudit ? (latestAudit.issues || 0) : 0,
      isLive: Math.random() > 0.2
    };
  });

  const recentActivity = audits.slice(0, 5).map(a => ({
    id: a.id,
    location: a.location,
    action: `Audit: ${a.score}/5`,
    time: 'Recent',
    status: a.score >= 4 ? 'success' : 'warning'
  }));

  const handleImageUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) {
      const reader = new FileReader();
      reader.onloadend = async () => {
        const resized = await resizeImage(reader.result as string);
        setImage(resized);
        setResult(null);
        setError(null);
      };
      reader.readAsDataURL(file);
    }
  };

  const startAnalysis = async () => {
    if (!image || !user) return;
    setIsAnalyzing(true);
    setError(null);
    try {
      const analysis = await analyzePostOfficeImage(image);
      setResult(analysis);
      
      // Save audit to Firestore
      const auditData = {
        date: serverTimestamp(),
        location: selectedLocation.name,
        score: analysis.cleanlinessScore,
        status: analysis.cleanlinessScore >= 4 ? 'Excellent' : analysis.cleanlinessScore >= 2.5 ? 'Good' : 'Needs Attention',
        issues: analysis.detectedObjects.litter.length + analysis.detectedObjects.infrastructureIssues.length + analysis.detectedObjects.maintenanceIssues.length,
        verified: analysis.locationVerification.isAuthentic,
        authorUid: user.uid,
        summary: analysis.summary,
        recommendations: analysis.recommendations,
        imageUrl: image // In a real app, we'd upload to Firebase Storage first
      };

      await addDoc(collection(db, 'audits'), auditData);

    } catch (err) {
      handleFirestoreError(err, OperationType.CREATE, 'audits');
    } finally {
      setIsAnalyzing(false);
    }
  };

  const logManualCleanup = async () => {
    if (!user || !beforeImage || !image) return;
    
    setIsLoggingCleanup(true);
    try {
      const auditData = {
        date: serverTimestamp(),
        timestamp: serverTimestamp(),
        location: selectedLocation.name,
        score: 5,
        status: 'Optimal',
        issues: 0,
        verified: true,
        authorUid: user.uid,
        beforeImageUrl: beforeImage,
        afterImageUrl: image,
        isCleanupLog: true,
        description: `Manual cleanup log for ${selectedLocation.name}`
      };

      await addDoc(collection(db, 'audits'), auditData);
      
      setBeforeImage(null);
      setImage(null);
      setResult(null);
      setIsCleanupMode(false);
      alert("Manual cleanup evidence logged successfully for ESG reporting!");
    } catch (err) {
      handleFirestoreError(err, OperationType.CREATE, 'audits');
    } finally {
      setIsLoggingCleanup(false);
    }
  };

  const reset = () => {
    setImage(null);
    setBeforeImage(null);
    setResult(null);
    setError(null);
    setIsCleanupMode(false);
  };

  const handleGoogleSignIn = async (forceSelect = false) => {
    try {
      const provider = new GoogleAuthProvider();
      if (forceSelect) {
        provider.setCustomParameters({ prompt: 'select_account' });
      }
      await signInWithPopup(auth, provider);
    } catch (err: any) {
      if (err.code === 'auth/popup-closed-by-user') {
        // User closed the popup, no need to show a scary error message
        return;
      }
      console.error("Sign in error:", err);
      setError("Failed to sign in with Google.");
    }
  };

  const handleSwitchAccount = async () => {
    try {
      await signOut(auth);
      handleGoogleSignIn(true);
    } catch (err) {
      console.error("Switch account error:", err);
    }
  };

  const handleRoleSelection = async (role: 'admin' | 'worker' | 'user') => {
    if (!user) return;
    try {
      const profile = {
        uid: user.uid,
        email: user.email,
        role,
        displayName: user.displayName,
        photoURL: user.photoURL,
        createdAt: serverTimestamp()
      };
      await setDoc(doc(db, 'users', user.uid), profile);
      setUserProfile({ role });
      setShowRoleSelection(false);
    } catch (err) {
      handleFirestoreError(err, OperationType.WRITE, `users/${user.uid}`);
    }
  };

  // Simulate AI Detections
  useEffect(() => {
    if (!user) return;
    
    const interval = setInterval(() => {
      const randomLocation = filteredPostOffices[Math.floor(Math.random() * filteredPostOffices.length)];
      const types = [
        { title: 'Garbage Detected', type: 'ai_detection', icon: Trash, color: 'text-rose-600', bg: 'bg-rose-50' },
        { title: 'Saturated Water', type: 'ai_detection', icon: Droplets, color: 'text-blue-600', bg: 'bg-blue-50' },
        { title: 'Bins Overflowing', type: 'ai_detection', icon: Trash2, color: 'text-amber-600', bg: 'bg-amber-50' }
      ];
      const selectedType = types[Math.floor(Math.random() * types.length)];
      
      setNotifications(prev => [{
        id: Date.now(),
        ...selectedType,
        location: randomLocation.name,
        time: 'Just now',
        restricted: true
      }, ...prev.slice(0, 9)]); // Keep last 10
    }, 45000); // Every 45 seconds

    return () => clearInterval(interval);
  }, [user]);

  const handleSignOut = () => signOut(auth);

  const submitComplaint = async () => {
    if (!user || (!image && !complaintDescription && !video && !documentFile)) {
      setError("Please provide at least an image, video, document or a description for your complaint.");
      return;
    }

    setIsSubmittingComplaint(true);
    setError(null);

    try {
      const complaintData = {
        date: serverTimestamp(),
        location: selectedLocation.name,
        description: complaintDescription || "No description provided",
        imageUrl: image || null,
        videoUrl: video || null,
        documentUrl: documentFile || null,
        status: 'pending',
        authorUid: user.uid,
        authorName: user.displayName || 'Anonymous',
        createdAt: serverTimestamp()
      };

      await addDoc(collection(db, 'complaints'), complaintData);
      
      // Add notification
      setNotifications(prev => [{
        id: Date.now(),
        type: 'complaint',
        title: 'New Complaint',
        location: selectedLocation.name,
        time: 'Just now',
        icon: MessageSquare,
        color: 'text-amber-600',
        bg: 'bg-amber-50',
        restricted: true
      }, ...prev]);

      setImage(null);
      setVideo(null);
      setDocumentFile(null);
      setComplaintDescription('');
      setActiveTab('reports');
      alert("Complaint submitted successfully! Our team will look into it.");
    } catch (err) {
      handleFirestoreError(err, OperationType.CREATE, 'complaints');
    } finally {
      setIsSubmittingComplaint(false);
    }
  };

  const resolveComplaint = async (complaintId: string, evidenceImage: string) => {
    if (!user || (userProfile?.role !== 'admin' && userProfile?.role !== 'worker')) return;
    
    setIsResolving(true);
    try {
      let complaintRef = doc(db, 'complaints', complaintId);
      let complaintSnap = await getDoc(complaintRef);
      
      if (!complaintSnap.exists()) {
        // Try audits collection for AI-detected issues
        complaintRef = doc(db, 'audits', complaintId);
        complaintSnap = await getDoc(complaintRef);
      }

      const complaintData = complaintSnap.data();
      if (!complaintData) throw new Error("Report not found");

      // 1. Update Report Status
      await setDoc(complaintRef, {
        status: 'resolved',
        resolvedBy: user.displayName || user.email,
        resolvedByUid: user.uid,
        resolvedAt: serverTimestamp(),
        afterImageUrl: evidenceImage
      }, { merge: true });

      // 2. Create ESG Audit Log (Digital Evidence)
      const auditData = {
        date: serverTimestamp(),
        timestamp: serverTimestamp(),
        location: complaintData.location,
        score: 5,
        status: 'Optimal',
        issues: 0,
        verified: true,
        authorUid: user.uid,
        beforeImageUrl: complaintData.imageUrl || null,
        afterImageUrl: evidenceImage,
        isCleanupLog: true,
        complaintId: complaintId,
        description: `Resolved ${complaintData.authorUid === 'system_ai' ? 'AI Detection' : 'Complaint'}: ${complaintData.description || complaintData.summary || 'No description'}`
      };

      await addDoc(collection(db, 'audits'), auditData);
      
      // Add notification
      setNotifications(prev => [{
        id: Date.now(),
        type: 'review',
        title: 'Cleanup Verified',
        location: complaintData.location,
        time: 'Just now',
        icon: CheckCircle2,
        color: 'text-emerald-600',
        bg: 'bg-emerald-50',
        restricted: false
      }, ...prev]);

      setResolvingComplaint(null);
      setAfterImage(null);
      alert("Cleanup evidence logged successfully for ESG reporting!");
    } catch (err) {
      handleFirestoreError(err, OperationType.UPDATE, `complaints/${complaintId}`);
    } finally {
      setIsResolving(false);
    }
  };

  const updateUserRole = async (userId: string, newRole: 'admin' | 'worker' | 'user') => {
    try {
      await setDoc(doc(db, 'users', userId), { role: newRole }, { merge: true });
      if (userId === user?.uid) {
        setUserProfile(prev => prev ? { ...prev, role: newRole } : { role: newRole });
      }
    } catch (err) {
      handleFirestoreError(err, OperationType.UPDATE, `users/${userId}`);
    }
  };

  const handleAddUser = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!newUserEmail || !newUserName) return;

    try {
      // We use a random ID since we don't have a Firebase Auth UID yet
      // In a real app, this would be an invitation system
      const tempId = `invited_${Date.now()}`;
      const profile = {
        uid: tempId,
        email: newUserEmail,
        role: newUserRole,
        displayName: newUserName,
        photoURL: null,
        createdAt: serverTimestamp(),
        isInvited: true
      };
      await setDoc(doc(db, 'users', tempId), profile);
      setShowAddUserModal(false);
      setNewUserEmail('');
      setNewUserName('');
      alert("User profile created successfully. They can now sign in with this email.");
    } catch (err) {
      handleFirestoreError(err, OperationType.WRITE, 'users');
    }
  };

  const deleteUserAccount = async (userId: string) => {
    if (!window.confirm("Are you sure you want to delete this user profile? This action cannot be undone.")) return;
    try {
      // Note: This only deletes the Firestore profile, not the Auth account.
      // In a production app, you'd use a Cloud Function for this.
      await setDoc(doc(db, 'users', userId), { deleted: true, role: 'deleted' }, { merge: true });
      // Or actual delete if rules allow
      // await deleteDoc(doc(db, 'users', userId)); 
    } catch (err) {
      handleFirestoreError(err, OperationType.DELETE, `users/${userId}`);
    }
  };

  if (showSplash) {
    return (
      <div className="min-h-screen bg-rose-600 flex flex-col items-center justify-center text-white p-4 overflow-hidden">
        <motion.div
          initial={{ opacity: 0, scale: 0.5, rotate: -10 }}
          animate={{ opacity: 1, scale: 1, rotate: 0 }}
          transition={{ duration: 0.8, ease: "easeOut" }}
          className="w-32 h-32 bg-white rounded-[2.5rem] flex items-center justify-center text-rose-600 shadow-2xl mb-8 relative"
        >
          <ShieldCheck size={64} />
          <motion.div
            animate={{ scale: [1, 1.2, 1], opacity: [0.3, 0.6, 0.3] }}
            transition={{ duration: 2, repeat: Infinity }}
            className="absolute inset-0 bg-white rounded-[2.5rem] -z-10 blur-xl"
          />
        </motion.div>
        
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.5, duration: 0.8 }}
          className="text-center"
        >
          <h1 className="text-4xl font-black tracking-tighter mb-2">SWACHHATA MONITOR</h1>
          <div className="flex items-center justify-center gap-3">
            <div className="h-px w-8 bg-white/30"></div>
            <p className="text-xs font-black uppercase tracking-[0.3em] text-rose-100">{currentDivision.name}</p>
            <div className="h-px w-8 bg-white/30"></div>
          </div>
        </motion.div>

        <motion.div
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          transition={{ delay: 1.5 }}
          className="absolute bottom-12 flex flex-col items-center gap-4"
        >
          <div className="flex items-center gap-3 opacity-60">
            <img src="https://upload.wikimedia.org/wikipedia/en/thumb/8/8c/India_Post_Logo.svg/1200px-India_Post_Logo.svg.png" alt="India Post" className="h-6 brightness-0 invert" referrerPolicy="no-referrer" />
            <div className="h-4 w-px bg-white/40"></div>
            <p className="text-[8px] font-bold uppercase tracking-widest">Department of Posts</p>
          </div>
          <RefreshCw className="animate-spin text-white/40" size={16} />
        </motion.div>
      </div>
    );
  }

  if (isAuthLoading) {
    return (
      <div className="min-h-screen bg-zinc-50 flex items-center justify-center">
        <RefreshCw className="animate-spin text-rose-600" size={32} />
      </div>
    );
  }

  if (!user) {
    return (
      <div className="min-h-screen bg-zinc-50 flex flex-col md:flex-row">
        {/* Left Side - Hero/Branding */}
        <div className="hidden md:flex md:w-1/2 bg-rose-600 p-12 flex-col justify-between text-white relative overflow-hidden">
          <div className="relative z-10">
            <div className="flex items-center gap-3 mb-12">
              <div className="w-10 h-10 bg-white rounded-xl flex items-center justify-center text-rose-600 shadow-lg">
                <ShieldCheck size={24} />
              </div>
              <h2 className="text-xl font-black tracking-tight">Swachhata Monitor</h2>
            </div>

            <div className="space-y-6 max-w-md">
              <h1 className="text-6xl font-black leading-[0.9] tracking-tighter">
                CLEANER <br />
                POST OFFICES <br />
                FOR ALL.
              </h1>
              <p className="text-rose-100/80 font-medium leading-relaxed">
                Real-time AI-powered cleanliness monitoring and ESG reporting system for the {currentDivision.name}, Department of Posts.
              </p>
            </div>
          </div>

          <div className="relative z-10 space-y-8">
            <div className="grid grid-cols-2 gap-8">
              <div>
                <p className="text-4xl font-black text-white">24/7</p>
                <p className="text-[10px] font-bold uppercase tracking-widest text-rose-200 mt-1">Live Monitoring</p>
              </div>
              <div>
                <p className="text-4xl font-black text-white">AI</p>
                <p className="text-[10px] font-bold uppercase tracking-widest text-rose-200 mt-1">Automated Audits</p>
              </div>
            </div>
            
            <div className="flex items-center gap-4 pt-8 border-t border-white/10">
              <img src="https://upload.wikimedia.org/wikipedia/en/thumb/8/8c/India_Post_Logo.svg/1200px-India_Post_Logo.svg.png" alt="India Post" className="h-8 brightness-0 invert" referrerPolicy="no-referrer" />
              <div className="h-8 w-px bg-white/20"></div>
              <p className="text-[10px] font-bold uppercase tracking-widest text-rose-100">Government of India Initiative</p>
            </div>
          </div>

          {/* Decorative Elements */}
          <div className="absolute top-[-10%] right-[-10%] w-[60%] aspect-square bg-white/5 rounded-full blur-3xl" />
          <div className="absolute bottom-[-20%] left-[-10%] w-[80%] aspect-square bg-black/10 rounded-full blur-3xl" />
        </div>

        {/* Right Side - Auth Form */}
        <div className="flex-1 flex items-center justify-center p-6 md:p-12">
          <motion.div 
            initial={{ opacity: 0, x: 20 }}
            animate={{ opacity: 1, x: 0 }}
            className="max-w-md w-full space-y-8"
          >
            <div className="md:hidden flex flex-col items-center text-center mb-8">
              <div className="w-16 h-16 bg-rose-600 rounded-2xl flex items-center justify-center text-white mb-4 shadow-xl">
                <ShieldCheck size={32} />
              </div>
              <h1 className="text-2xl font-black tracking-tight">Swachhata Monitor</h1>
              <p className="text-zinc-500 text-sm font-medium">{currentDivision.name} • India Post</p>
            </div>

            <div className="space-y-2">
              <h2 className="text-3xl font-black tracking-tight text-zinc-900">Get Started</h2>
              <p className="text-zinc-500 font-medium">Create an account or sign in to access the monitoring dashboard</p>
            </div>
            
            <div className="space-y-4">
              {error && (
                <div className="p-4 bg-rose-50 border border-rose-100 rounded-2xl text-rose-600 text-xs font-bold flex items-center gap-3">
                  <AlertTriangle size={16} className="shrink-0" />
                  <p className="text-left">{error}</p>
                </div>
              )}
              
              <div className="space-y-3">
                <button 
                  onClick={() => handleGoogleSignIn()}
                  className="w-full py-4 bg-rose-600 text-white rounded-2xl font-bold flex items-center justify-center gap-3 hover:bg-rose-500 transition-all hover:scale-[1.02] active:scale-[0.98] shadow-xl shadow-rose-900/20 group"
                >
                  <img src="https://www.google.com/favicon.ico" className="w-5 h-5 brightness-0 invert" alt="Google" />
                  <span>Sign up with Google</span>
                </button>
                
                <div className="relative py-4">
                  <div className="absolute inset-0 flex items-center">
                    <div className="w-full border-t border-zinc-100"></div>
                  </div>
                  <div className="relative flex justify-center text-[10px] uppercase tracking-widest font-black text-zinc-300">
                    <span className="bg-white px-4">Already have an account?</span>
                  </div>
                </div>

                <button 
                  onClick={() => handleGoogleSignIn()}
                  className="w-full py-4 bg-white border-2 border-zinc-900 text-zinc-900 rounded-2xl font-bold flex items-center justify-center gap-3 hover:bg-zinc-50 transition-all hover:scale-[1.02] active:scale-[0.98]"
                >
                  <img src="https://www.google.com/favicon.ico" className="w-5 h-5" alt="Google" />
                  <span>Sign in with Google</span>
                </button>
              </div>
            </div>

            <div className="pt-8 border-t border-zinc-100">
              <div className="flex items-center justify-between text-[10px] font-black uppercase tracking-widest text-zinc-400">
                <a href="#" className="hover:text-rose-600 transition-colors">Privacy Policy</a>
                <div className="w-1 h-1 bg-zinc-200 rounded-full"></div>
                <a href="#" className="hover:text-rose-600 transition-colors">Terms of Service</a>
                <div className="w-1 h-1 bg-zinc-200 rounded-full"></div>
                <a href="#" className="hover:text-rose-600 transition-colors">Help Center</a>
              </div>
            </div>
          </motion.div>
        </div>
      </div>
    );
  }

  if (showRoleSelection) {
    return (
      <div className="min-h-screen bg-zinc-50 flex items-center justify-center p-4">
        <motion.div 
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          className="max-w-2xl w-full space-y-8"
        >
          <div className="text-center">
            <h2 className="text-3xl font-black tracking-tight">Select Your Role</h2>
            <p className="text-zinc-500 mt-2">Choose the account type that matches your responsibilities</p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
            {[
              { id: 'admin', title: 'Administrator', desc: 'Full system access, analytics, and user management.', icon: ShieldCheck, color: 'text-rose-600', bg: 'bg-rose-50' },
              { id: 'worker', title: 'Audit Worker', desc: 'Perform live audits and report cleanliness issues.', icon: Camera, color: 'text-blue-600', bg: 'bg-blue-50' },
              { id: 'user', title: 'Public User', desc: 'View dashboard analytics and cleanliness reports.', icon: LayoutDashboard, color: 'text-emerald-600', bg: 'bg-emerald-50' },
            ].map((role) => (
              <button
                key={role.id}
                onClick={() => handleRoleSelection(role.id as any)}
                className="bg-white p-8 rounded-3xl border-2 border-zinc-100 hover:border-rose-500 hover:shadow-xl transition-all text-left group"
              >
                <div className={`w-12 h-12 ${role.bg} ${role.color} rounded-xl flex items-center justify-center mb-6 group-hover:scale-110 transition-transform`}>
                  <role.icon size={24} />
                </div>
                <h3 className="font-black text-lg mb-2">{role.title}</h3>
                <p className="text-xs text-zinc-500 leading-relaxed font-medium">{role.desc}</p>
              </button>
            ))}
          </div>
        </motion.div>
      </div>
    );
  }

  const getScoreColor = (score: number | string) => {
    const s = typeof score === 'string' ? parseFloat(score) : score;
    if (s >= 4) return 'text-emerald-500';
    if (s >= 2.5) return 'text-amber-500';
    return 'text-rose-500';
  };

  const getScoreBg = (score: number | string) => {
    const s = typeof score === 'string' ? parseFloat(score) : score;
    if (s >= 4) return 'bg-emerald-50';
    if (s >= 2.5) return 'bg-amber-50';
    return 'bg-rose-50';
  };

  const filteredNotifications = notifications.filter(n => {
    // No notifications to users
    if (userProfile?.role === 'user') return false;

    // Basic role restriction
    const canSeeRestricted = userProfile?.role === 'admin' || userProfile?.role === 'worker';
    if (n.restricted && !canSeeRestricted) return false;

    // Worker preference filtering
    if (userProfile?.role === 'worker' && userProfile.notificationPreferences) {
      const prefs = userProfile.notificationPreferences;
      if (n.type === 'ai_detection') {
        if (n.issueType === 'garbage' && prefs.garbage === false) return false;
        if (n.issueType === 'water' && prefs.water === false) return false;
        if (n.issueType === 'overflow' && prefs.overflow === false) return false;
      }
      if (n.type === 'complaint' && prefs.complaints === false) return false;
    }

    return true;
  });

  return (
    <ErrorBoundary>
      <div className="min-h-screen bg-zinc-50 text-zinc-900 font-sans">
      {/* Header */}
      <header className="bg-white border-b border-zinc-200 sticky top-0 z-20">
        <div className="max-w-6xl mx-auto px-4 h-16 flex items-center justify-between">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 bg-rose-600 rounded-lg flex items-center justify-center text-white shadow-sm">
              <ShieldCheck size={24} />
            </div>
            <div>
              <h1 className="font-bold text-lg leading-tight">Swachhata Monitor</h1>
              <div className="relative">
                <button 
                  onClick={() => setShowDivisionSelector(!showDivisionSelector)}
                  className="flex items-center gap-1.5 text-xs text-zinc-500 hover:text-rose-600 transition-colors font-semibold uppercase tracking-wider"
                >
                  {currentDivision.name} • India Post
                  <ChevronDown size={12} />
                </button>

                <AnimatePresence>
                  {showDivisionSelector && (
                    <>
                      <div className="fixed inset-0 z-30" onClick={() => setShowDivisionSelector(false)} />
                      <motion.div
                        initial={{ opacity: 0, y: 10 }}
                        animate={{ opacity: 1, y: 0 }}
                        exit={{ opacity: 0, y: 10 }}
                        className="absolute left-0 mt-2 w-56 bg-white rounded-2xl shadow-2xl border border-zinc-100 z-40 overflow-hidden"
                      >
                        <div className="p-3 border-b border-zinc-50">
                          <p className="text-[10px] font-black text-zinc-400 uppercase tracking-widest">Select Division</p>
                        </div>
                        <div className="p-2">
                          {DIVISIONS.map(division => (
                            <button
                              key={division.id}
                              onClick={() => {
                                setSelectedDivisionId(division.id);
                                setShowDivisionSelector(false);
                              }}
                              className={`w-full text-left px-4 py-2.5 rounded-xl text-xs font-bold transition-all flex items-center justify-between ${
                                selectedDivisionId === division.id ? 'bg-rose-50 text-rose-600' : 'hover:bg-zinc-50 text-zinc-600'
                              }`}
                            >
                              {division.name}
                              {selectedDivisionId === division.id && <CheckCircle2 size={14} />}
                            </button>
                          ))}
                        </div>
                      </motion.div>
                    </>
                  )}
                </AnimatePresence>
              </div>
            </div>
          </div>
          
          <nav className="hidden md:flex items-center bg-zinc-100 p-1 rounded-xl">
            <button 
              onClick={() => setActiveTab('dashboard')}
              className={`px-4 py-2 rounded-lg text-xs font-bold flex items-center gap-2 transition-all ${activeTab === 'dashboard' ? 'bg-white text-zinc-900 shadow-sm' : 'text-zinc-500 hover:text-zinc-700'}`}
            >
              <LayoutDashboard size={14} /> DASHBOARD
            </button>
            <button 
              onClick={() => setActiveTab('analytics')}
              className={`px-4 py-2 rounded-lg text-xs font-bold flex items-center gap-2 transition-all ${activeTab === 'analytics' ? 'bg-white text-zinc-900 shadow-sm' : 'text-zinc-500 hover:text-zinc-700'}`}
            >
              <BarChart3 size={14} /> ANALYTICS
            </button>
            <button 
              onClick={() => setActiveTab('reports')}
              className={`px-4 py-2 rounded-lg text-xs font-bold flex items-center gap-2 transition-all ${activeTab === 'reports' ? 'bg-white text-zinc-900 shadow-sm' : 'text-zinc-500 hover:text-zinc-700'}`}
            >
              <MessageSquare size={14} /> REPORTS
            </button>
            {userProfile?.role === 'admin' && (
              <button 
                onClick={() => setActiveTab('users')}
                className={`px-4 py-2 rounded-lg text-xs font-bold flex items-center gap-2 transition-all ${activeTab === 'users' ? 'bg-white text-zinc-900 shadow-sm' : 'text-zinc-500 hover:text-zinc-700'}`}
              >
                <Users size={14} /> USERS
              </button>
            )}
            {(userProfile?.role === 'admin' || userProfile?.role === 'worker') && (
              <button 
                onClick={() => setActiveTab('audit')}
                className={`px-4 py-2 rounded-lg text-xs font-bold flex items-center gap-2 transition-all ${activeTab === 'audit' ? 'bg-white text-zinc-900 shadow-sm' : 'text-zinc-500 hover:text-zinc-700'}`}
              >
                <Camera size={14} /> LIVE AUDIT
              </button>
            )}
          </nav>

          <div className="flex items-center gap-4 text-xs font-medium text-zinc-500">
            <span className="hidden sm:flex items-center gap-1"><MapPin size={14} /> Amravati, MH</span>
            
            {/* Notifications */}
            {(userProfile?.role === 'admin' || userProfile?.role === 'worker') && (
              <div className="relative">
                <button 
                  onClick={() => setShowNotifications(!showNotifications)}
                  className={`w-10 h-10 rounded-xl flex items-center justify-center transition-all relative ${showNotifications ? 'bg-rose-50 text-rose-600' : 'bg-zinc-100 text-zinc-500 hover:bg-zinc-200'}`}
                >
                  {filteredNotifications.length > 0 && (
                    <span className="absolute -top-1 -right-1 w-4 h-4 bg-rose-600 text-white text-[8px] font-black rounded-full flex items-center justify-center border-2 border-white animate-bounce">
                      {filteredNotifications.length}
                    </span>
                  )}
                  <Bell size={18} />
                </button>

                <AnimatePresence>
                  {showNotifications && (
                    <>
                      <div className="fixed inset-0 z-30" onClick={() => setShowNotifications(false)} />
                      <motion.div
                        initial={{ opacity: 0, y: 10, scale: 0.95 }}
                        animate={{ opacity: 1, y: 0, scale: 1 }}
                        exit={{ opacity: 0, y: 10, scale: 0.95 }}
                        className="absolute right-0 mt-2 w-80 bg-white rounded-3xl shadow-2xl border border-zinc-100 z-40 overflow-hidden"
                      >
                        <div className="p-5 border-b border-zinc-50 flex items-center justify-between">
                          <h3 className="text-xs font-black uppercase tracking-widest text-zinc-900">Notifications</h3>
                          <button 
                            onClick={() => {
                              // In a real app, we'd mark all as read in Firestore
                              setNotifications([]);
                            }}
                            className="text-[10px] font-bold text-rose-600 hover:underline"
                          >
                            Clear All
                          </button>
                        </div>
                        <div className="max-h-[400px] overflow-y-auto">
                          {filteredNotifications.length > 0 ? (
                            filteredNotifications.map((notif) => {
                              const Icon = getNotifIcon(notif.type, notif.issueType);
                              const colorClass = getNotifColor(notif.type);
                              return (
                                <div 
                                  key={notif.id} 
                                  onClick={() => {
                                    setActiveTab('reports');
                                    if (notif.type === 'review') {
                                      setReportView('reviews');
                                    } else {
                                      setReportView('complaints');
                                    }
                                    setShowNotifications(false);
                                  }}
                                  className="p-4 border-b border-zinc-50 hover:bg-zinc-50 transition-colors cursor-pointer group"
                                >
                                  <div className="flex gap-4">
                                    <div className={`w-10 h-10 rounded-xl ${colorClass} flex items-center justify-center shrink-0 group-hover:scale-110 transition-transform`}>
                                      <Icon size={18} />
                                    </div>
                                    <div className="space-y-1">
                                      <div className="flex items-center justify-between gap-2">
                                        <p className="text-[10px] font-black text-zinc-900 uppercase tracking-tight">{notif.title}</p>
                                        <span className="text-[8px] font-bold text-zinc-400 uppercase">{notif.time}</span>
                                      </div>
                                      <p className="text-[11px] text-zinc-600 font-medium leading-tight">
                                        {notif.message || (notif.type === 'ai_detection' ? `AI detected an issue at ${notif.location}` : `New activity reported at ${notif.location}`)}
                                      </p>
                                      <div className="flex items-center gap-1 text-[9px] font-bold text-zinc-400 uppercase">
                                        <MapPin size={8} /> {notif.location}
                                      </div>
                                    </div>
                                  </div>
                                </div>
                              );
                            })
                          ) : (
                            <div className="p-12 text-center space-y-3">
                              <div className="w-12 h-12 bg-zinc-50 rounded-full flex items-center justify-center mx-auto text-zinc-200">
                                <Bell size={24} />
                              </div>
                              <p className="text-xs font-bold text-zinc-400">All caught up!</p>
                            </div>
                          )}
                        </div>
                        <div className="p-4 bg-zinc-50 text-center">
                          <button 
                            onClick={() => {
                              setActiveTab('reports');
                              setShowNotifications(false);
                            }}
                            className="text-[10px] font-black uppercase tracking-widest text-zinc-500 hover:text-zinc-900 transition-colors"
                          >
                            View All Activity
                          </button>
                        </div>
                      </motion.div>
                    </>
                  )}
                </AnimatePresence>
              </div>
            )}

            <div className="relative">
              <button 
                onClick={() => setShowUserMenu(!showUserMenu)}
                className="flex items-center gap-3 hover:bg-zinc-50 p-1 rounded-xl transition-all"
              >
                <div className="text-right hidden sm:block">
                  <p className="text-[10px] font-black leading-none text-zinc-900">{user?.displayName}</p>
                  <p className="text-[8px] font-bold text-zinc-400 uppercase tracking-widest mt-1">{userProfile?.role}</p>
                </div>
                <div className="w-8 h-8 rounded-full bg-zinc-200 flex items-center justify-center text-zinc-500 font-bold overflow-hidden border border-zinc-300">
                  {user?.photoURL ? <img src={user.photoURL} alt="avatar" /> : user?.displayName?.charAt(0)}
                </div>
                <ChevronDown size={14} className={`transition-transform ${showUserMenu ? 'rotate-180' : ''}`} />
              </button>

              <AnimatePresence>
                {showUserMenu && (
                  <>
                    <div 
                      className="fixed inset-0 z-30" 
                      onClick={() => setShowUserMenu(false)}
                    />
                    <motion.div
                      initial={{ opacity: 0, y: 10, scale: 0.95 }}
                      animate={{ opacity: 1, y: 0, scale: 1 }}
                      exit={{ opacity: 0, y: 10, scale: 0.95 }}
                      className="absolute right-0 mt-2 w-56 bg-white rounded-2xl shadow-xl border border-zinc-100 py-2 z-40 overflow-hidden"
                    >
                      <div className="px-4 py-3 border-b border-zinc-50 mb-1">
                        <p className="text-[10px] font-black text-zinc-900 truncate">{user?.displayName}</p>
                        <p className="text-[9px] text-zinc-400 truncate">{user?.email}</p>
                      </div>

                      <div className="px-4 py-2 border-b border-zinc-50">
                        <p className="text-[8px] font-black text-zinc-400 uppercase tracking-widest mb-2">Switch Role (Demo)</p>
                        <div className="flex flex-wrap gap-1">
                          {['admin', 'worker', 'user'].map((r) => (
                            <button
                              key={r}
                              onClick={() => updateUserRole(user!.uid, r as any)}
                              className={`px-2 py-1 rounded-md text-[8px] font-black uppercase tracking-tighter transition-all ${
                                userProfile?.role === r 
                                  ? 'bg-rose-600 text-white' 
                                  : 'bg-zinc-100 text-zinc-500 hover:bg-zinc-200'
                              }`}
                            >
                              {r}
                            </button>
                          ))}
                        </div>
                      </div>
                      
                      <button 
                        onClick={() => {
                          setShowSettings(true);
                          setShowUserMenu(false);
                        }}
                        className="w-full px-4 py-2.5 text-left text-xs font-bold text-zinc-600 hover:bg-zinc-50 flex items-center gap-3 transition-colors"
                      >
                        <Settings2 size={14} className="text-zinc-400" />
                        Settings
                      </button>

                      <button 
                        onClick={() => {
                          setShowUserMenu(false);
                          handleSwitchAccount();
                        }}
                        className="w-full px-4 py-2.5 text-left text-xs font-bold text-zinc-600 hover:bg-zinc-50 flex items-center gap-3 transition-colors"
                      >
                        <UserPlus size={14} className="text-zinc-400" />
                        Add another account
                      </button>
                      
                      <button 
                        onClick={() => {
                          setShowUserMenu(false);
                          handleSignOut();
                        }}
                        className="w-full px-4 py-2.5 text-left text-xs font-bold text-rose-600 hover:bg-rose-50 flex items-center gap-3 transition-colors"
                      >
                        <LogOut size={14} className="text-rose-400" />
                        Sign out
                      </button>
                    </motion.div>
                  </>
                )}
              </AnimatePresence>
            </div>
          </div>
        </div>
      </header>

      <main className="max-w-6xl mx-auto px-4 py-8">
        <AnimatePresence mode="wait">
          {activeTab === 'dashboard' ? (
            <motion.div 
              key="dashboard"
              initial={{ opacity: 0, y: 10 }}
              animate={{ opacity: 1, y: 0 }}
              exit={{ opacity: 0, y: -10 }}
              className="space-y-8"
            >
              {/* Stats Overview */}
              <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
                {(userProfile?.role === 'admin' || userProfile?.role === 'worker' || userProfile?.role === 'user' ? [
                  { label: 'Total Locations', value: filteredPostOffices.length, icon: Building2, color: 'text-blue-600', bg: 'bg-blue-50' },
                  { label: 'Average Score', value: '4.2', icon: Star, color: 'text-amber-600', bg: 'bg-amber-50' },
                  { label: 'Active Alerts', value: '3', icon: AlertTriangle, color: 'text-rose-600', bg: 'bg-rose-50' },
                  { label: 'Live Monitors', value: `${filteredPostOffices.length}/${filteredPostOffices.length}`, icon: Activity, color: 'text-emerald-600', bg: 'bg-emerald-50' },
                ] : [
                  { label: 'Total Locations', value: filteredPostOffices.length, icon: Building2, color: 'text-blue-600', bg: 'bg-blue-50' },
                  { label: 'Cleanliness Score', value: '4.2', icon: Star, color: 'text-amber-600', bg: 'bg-amber-50' },
                  { label: 'Audits Completed', value: '128', icon: CheckCircle2, color: 'text-emerald-600', bg: 'bg-emerald-50' },
                  { label: 'Community Reports', value: '45', icon: MessageSquare, color: 'text-rose-600', bg: 'bg-rose-50' },
                ]).map((stat, i) => (
                  <div key={i} className="bg-white p-6 rounded-2xl border border-zinc-200 shadow-sm flex items-center gap-4">
                    <div className={`w-12 h-12 ${stat.bg} ${stat.color} rounded-xl flex items-center justify-center`}>
                      <stat.icon size={24} />
                    </div>
                    <div>
                      <p className="text-[10px] font-bold text-zinc-400 uppercase tracking-widest">{stat.label}</p>
                      <p className="text-2xl font-black">{stat.value}</p>
                    </div>
                  </div>
                ))}
              </div>

              {/* Dashboard Content */}
              <div className="grid grid-cols-1 lg:grid-cols-12 gap-8">
                {userProfile?.role === 'admin' || userProfile?.role === 'worker' || userProfile?.role === 'user' ? (
                  <>
                    {/* Real-time Monitoring Grid & Activity */}
                    <section className="lg:col-span-8 space-y-4">
                      <div className="flex items-center justify-between">
                        <h2 className="text-xl font-black tracking-tight flex items-center gap-2">
                          <Activity size={20} className="text-rose-600" />
                          REAL-TIME MONITORING
                        </h2>
                        <div className="flex items-center gap-2">
                          <div className="relative">
                            <Search className="absolute left-3 top-1/2 -translate-y-1/2 text-zinc-400" size={14} />
                            <input 
                              type="text" 
                              placeholder="Search locations..." 
                              className="pl-9 pr-4 py-2 bg-white border border-zinc-200 rounded-lg text-xs focus:outline-none focus:ring-2 focus:ring-rose-500/20"
                            />
                          </div>
                        </div>
                      </div>

                      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                        {dashboardData.map((po) => (
                          <motion.div 
                            key={po.id}
                            whileHover={{ y: -4 }}
                            className="bg-white rounded-2xl border border-zinc-200 overflow-hidden shadow-sm hover:shadow-md transition-all cursor-pointer relative"
                            onClick={() => {
                              setViewingLiveFeed(po.id);
                            }}
                          >
                            {po.isLive && (
                              <div className="absolute top-3 right-3 flex items-center gap-1 bg-rose-600 text-white px-2 py-0.5 rounded-full text-[8px] font-black animate-pulse z-10">
                                <div className="w-1 h-1 bg-white rounded-full"></div> LIVE
                              </div>
                            )}
                            <div className="p-5 space-y-4">
                              <div className="flex justify-between items-start">
                                <div>
                                  <h3 className="font-bold text-sm leading-tight">{po.name}</h3>
                                  <p className="text-[10px] text-zinc-500 mt-0.5">{po.area}</p>
                                </div>
                                <div className={`px-2 py-1 rounded text-[10px] font-bold uppercase ${getScoreBg(po.score)} ${getScoreColor(po.score)}`}>
                                  {po.score}
                                </div>
                              </div>

                              <div className="flex items-center justify-between py-2 border-y border-zinc-50">
                                <div className="flex items-center gap-1.5">
                                  <div className={`w-2 h-2 rounded-full ${po.status === 'Clean' ? 'bg-emerald-500' : 'bg-amber-500'}`}></div>
                                  <span className="text-[10px] font-bold text-zinc-600 uppercase">{po.status}</span>
                                </div>
                                <div className="flex items-center gap-1 text-[10px] text-zinc-400">
                                  <Clock size={10} /> {po.lastAudit}
                                </div>
                              </div>

                              <div className="flex items-center justify-between">
                                <div className="flex -space-x-2">
                                  {[1, 2, 3].map(i => (
                                    <div key={i} className="w-6 h-6 rounded-full border-2 border-white bg-zinc-100 flex items-center justify-center text-[8px] font-bold text-zinc-400 overflow-hidden">
                                      <img src={`https://picsum.photos/seed/po-${po.id}-${i}/40/40`} alt="feed" referrerPolicy="no-referrer" />
                                    </div>
                                  ))}
                                </div>
                                {po.activeAlerts > 0 && (
                                  <span className="text-[10px] font-bold text-rose-600 flex items-center gap-1">
                                    <AlertTriangle size={10} /> {po.activeAlerts} Alerts
                                  </span>
                                )}
                              </div>
                            </div>
                            <div className="bg-zinc-50 px-5 py-3 border-t border-zinc-100 flex items-center justify-between group">
                              <span className="text-[10px] font-bold text-zinc-400 uppercase tracking-wider">View Live Feed</span>
                              <ChevronRight size={14} className="text-zinc-300 group-hover:text-rose-600 group-hover:translate-x-1 transition-all" />
                            </div>
                          </motion.div>
                        ))}
                      </div>
                    </section>
                  </>
                ) : (
                  <section className="lg:col-span-8 space-y-6">
                    <div className="bg-white p-8 rounded-3xl border border-zinc-200 shadow-sm space-y-6">
                      <div className="space-y-2">
                        <h2 className="text-2xl font-black tracking-tight flex items-center gap-3">
                          <ShieldCheck size={28} className="text-rose-600" />
                          PUBLIC DASHBOARD
                        </h2>
                        <p className="text-sm text-zinc-500 leading-relaxed">
                          Welcome to the Swachhata Monitor transparency portal. We are committed to maintaining the highest standards of cleanliness across all {currentDivision.name} post offices.
                        </p>
                      </div>

                      <div className="grid grid-cols-1 md:grid-cols-2 gap-6 pt-4">
                        <div className="p-6 bg-zinc-50 rounded-2xl border border-zinc-100 space-y-4">
                          <div className="w-10 h-10 bg-white rounded-xl flex items-center justify-center text-rose-600 shadow-sm">
                            <BarChart3 size={20} />
                          </div>
                          <h3 className="font-bold text-sm uppercase tracking-tight">View Analytics</h3>
                          <p className="text-[10px] text-zinc-500 font-medium">Explore detailed cleanliness trends and performance data for your local post office.</p>
                          <button 
                            onClick={() => setActiveTab('analytics')}
                            className="text-[10px] font-black text-rose-600 hover:underline uppercase tracking-widest"
                          >
                            OPEN ANALYTICS →
                          </button>
                        </div>

                        <div className="p-6 bg-rose-50 rounded-2xl border border-rose-100 space-y-4">
                          <div className="w-10 h-10 bg-white rounded-xl flex items-center justify-center text-rose-600 shadow-sm">
                            <MessageSquare size={20} />
                          </div>
                          <h3 className="font-bold text-sm uppercase tracking-tight">File a Complaint</h3>
                          <p className="text-[10px] text-zinc-500 font-medium">Notice an issue? Report it directly to our team with photo or video evidence.</p>
                          <button 
                            onClick={() => setActiveTab('reports')}
                            className="text-[10px] font-black text-rose-600 hover:underline uppercase tracking-widest"
                          >
                            REPORT ISSUE →
                          </button>
                        </div>
                      </div>

                      <div className="p-6 border border-zinc-100 rounded-2xl bg-white">
                        <h3 className="text-xs font-black uppercase tracking-widest mb-4 flex items-center gap-2">
                          <Star size={14} className="text-amber-500" />
                          Top Performing Locations
                        </h3>
                        <div className="space-y-3">
                          {filteredPostOffices.slice(0, 3).map((po, i) => (
                            <div key={po.id} className="flex items-center justify-between p-3 bg-zinc-50 rounded-xl">
                              <div className="flex items-center gap-3">
                                <span className="text-xs font-black text-zinc-300">0{i+1}</span>
                                <span className="text-xs font-bold">{po.name}</span>
                              </div>
                              <div className="flex items-center gap-1">
                                <Star size={10} className="fill-amber-500 text-amber-500" />
                                <span className="text-xs font-black">4.9</span>
                              </div>
                            </div>
                          ))}
                        </div>
                      </div>
                    </div>
                  </section>
                )}

                <aside className="lg:col-span-4 space-y-6">
                  <div className="bg-white rounded-2xl border border-zinc-200 p-6 shadow-sm">
                    <h2 className="text-sm font-black tracking-tight mb-4 flex items-center gap-2">
                      <Clock size={16} className="text-zinc-400" />
                      RECENT ACTIVITY
                    </h2>
                    <div className="space-y-4">
                      {recentActivity.map((activity) => (
                        <div key={activity.id} className="flex gap-3 group cursor-default">
                          <div className={`w-1.5 h-1.5 rounded-full mt-1.5 shrink-0 ${
                            activity.status === 'success' ? 'bg-emerald-500' : 
                            activity.status === 'warning' ? 'bg-rose-500' : 'bg-blue-500'
                          }`}></div>
                          <div>
                            <p className="text-xs font-bold group-hover:text-rose-600 transition-colors">{activity.location}</p>
                            <p className="text-[10px] text-zinc-500">{activity.action}</p>
                            <p className="text-[9px] text-zinc-400 mt-1">{activity.time}</p>
                          </div>
                        </div>
                      ))}
                    </div>
                    {(userProfile?.role === 'admin' || userProfile?.role === 'worker') && (
                      <button 
                        onClick={() => setActiveTab('audit')}
                        className="w-full mt-6 py-3 bg-zinc-100 text-zinc-600 rounded-xl text-[10px] font-black uppercase tracking-widest hover:bg-zinc-200 transition-colors"
                      >
                        START NEW AUDIT
                      </button>
                    )}
                  </div>

                  <div className="bg-zinc-900 rounded-2xl p-6 text-white shadow-xl">
                    <h3 className="text-xs font-bold text-zinc-400 uppercase tracking-widest mb-3">System Status</h3>
                    <div className="space-y-3">
                      <div className="flex justify-between items-center">
                        <span className="text-[10px] text-zinc-400">AI Engine</span>
                        <span className="text-[10px] font-bold text-emerald-400">Operational</span>
                      </div>
                      <div className="flex justify-between items-center">
                        <span className="text-[10px] text-zinc-400">Camera Feeds</span>
                        <span className="text-[10px] font-bold text-emerald-400">8/8 Online</span>
                      </div>
                      {(userProfile?.role === 'admin' || userProfile?.role === 'worker' || userProfile?.role === 'user') && (
                        <div className="flex justify-between items-center">
                          <span className="text-[10px] text-zinc-400">AI Detection</span>
                          <span className="text-[10px] font-bold text-emerald-400">Active</span>
                        </div>
                      )}
                      <div className="flex justify-between items-center">
                        <span className="text-[10px] text-zinc-400">Database</span>
                        <span className="text-[10px] font-bold text-emerald-400">Synced</span>
                      </div>
                    </div>
                  </div>
                </aside>
              </div>
            </motion.div>
          ) : activeTab === 'analytics' ? (
            <motion.div 
              key="analytics"
              initial={{ opacity: 0, y: 10 }}
              animate={{ opacity: 1, y: 0 }}
              exit={{ opacity: 0, y: -10 }}
              className="space-y-8"
            >
              {/* Analytics Header */}
              <div className="flex flex-col md:flex-row justify-between items-start md:items-center gap-4">
                <div>
                  <h2 className="text-2xl font-black tracking-tight flex items-center gap-2">
                    <BarChart3 size={24} className="text-rose-600" />
                    DATA REPORTS & ANALYTICS
                  </h2>
                  <p className="text-sm text-zinc-500">Comprehensive cleanliness performance across {currentDivision.name}</p>
                </div>
                <div className="flex items-center gap-3">
                  <div className="relative">
                    <Filter className="absolute left-3 top-1/2 -translate-y-1/2 text-zinc-400" size={14} />
                    <select 
                      value={analyticsFilter}
                      onChange={(e) => setAnalyticsFilter(e.target.value)}
                      className="pl-9 pr-4 py-2 bg-white border border-zinc-200 rounded-xl text-xs font-bold text-zinc-600 focus:outline-none focus:ring-2 focus:ring-rose-500/20 appearance-none"
                    >
                      <option>All Locations</option>
                      {POST_OFFICES.map(po => (
                        <option key={po.id}>{po.name}</option>
                      ))}
                    </select>
                  </div>
                  <button 
                    onClick={exportReport}
                    className="flex items-center gap-2 px-4 py-2 bg-zinc-900 text-white rounded-xl text-xs font-bold hover:bg-zinc-800 transition-all shadow-lg shadow-zinc-200"
                  >
                    <Download size={14} /> EXPORT REPORT
                  </button>
                </div>
              </div>

              {/* Key Performance Indicators */}
              <div className="grid grid-cols-1 md:grid-cols-2 xl:grid-cols-4 gap-6">
                <div className="bg-white p-6 rounded-3xl border border-zinc-200 shadow-sm">
                  <p className="text-[10px] font-bold text-zinc-400 uppercase tracking-widest mb-1">Weekly Improvement</p>
                  <div className="flex items-end gap-2">
                    <h4 className="text-3xl font-black text-emerald-600">+12%</h4>
                    <TrendingUp size={20} className="text-emerald-500 mb-1.5" />
                  </div>
                  <p className="text-[10px] text-zinc-500 mt-2">Compared to previous week (Avg: 3.8 → 4.3)</p>
                </div>
                <div className="bg-white p-6 rounded-3xl border border-zinc-200 shadow-sm">
                  <p className="text-[10px] font-bold text-zinc-400 uppercase tracking-widest mb-1">Compliance Rate</p>
                  <div className="flex items-end gap-2">
                    <h4 className="text-3xl font-black text-blue-600">94.2%</h4>
                    <ShieldCheck size={20} className="text-blue-500 mb-1.5" />
                  </div>
                  <p className="text-[10px] text-zinc-500 mt-2">Audits meeting Swachhata standards</p>
                </div>
                <div className="bg-white p-6 rounded-3xl border border-zinc-200 shadow-sm">
                  <p className="text-[10px] font-bold text-zinc-400 uppercase tracking-widest mb-1">Response Time</p>
                  <div className="flex items-end gap-2">
                    <h4 className="text-3xl font-black text-amber-600">24m</h4>
                    <Clock size={20} className="text-amber-500 mb-1.5" />
                  </div>
                  <p className="text-[10px] text-zinc-500 mt-2">Avg. time to resolve detected litter</p>
                </div>
                <div className="bg-white p-6 rounded-3xl border border-zinc-200 shadow-sm">
                  <p className="text-[10px] font-bold text-zinc-400 uppercase tracking-widest mb-1">ESG Accountability</p>
                  <div className="flex items-end gap-2">
                    <h4 className="text-3xl font-black text-rose-600">{audits.filter(a => a.isCleanupLog).length}</h4>
                    <Shield size={20} className="text-rose-500 mb-1.5" />
                  </div>
                  <p className="text-[10px] text-zinc-500 mt-2">Verified before/after cleanup logs</p>
                </div>
              </div>

              {/* Analytics Grid */}
              <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
                {/* Score Trend */}
                <div className="lg:col-span-8 bg-white p-6 rounded-3xl border border-zinc-200 shadow-sm space-y-6">
                  <div className="flex items-center justify-between">
                    <h3 className="text-sm font-black tracking-tight flex items-center gap-2 uppercase">
                      <TrendingUp size={16} className="text-emerald-500" />
                      Cleanliness Score Trend
                    </h3>
                    <div className="flex items-center gap-4">
                      <div className="flex items-center gap-1.5">
                        <div className="w-2 h-2 rounded-full bg-rose-500"></div>
                        <span className="text-[10px] font-bold text-zinc-400 uppercase">Current Week</span>
                      </div>
                      <div className="flex items-center gap-1.5">
                        <div className="w-2 h-2 rounded-full bg-zinc-200"></div>
                        <span className="text-[10px] font-bold text-zinc-400 uppercase">Previous Week</span>
                      </div>
                    </div>
                  </div>
                  <div className="h-[300px] w-full">
                    <ResponsiveContainer width="100%" height="100%">
                      <AreaChart data={trendData}>
                        <defs>
                          <linearGradient id="colorScore" x1="0" y1="0" x2="0" y2="1">
                            <stop offset="5%" stopColor="#f43f5e" stopOpacity={0.1}/>
                            <stop offset="95%" stopColor="#f43f5e" stopOpacity={0}/>
                          </linearGradient>
                        </defs>
                        <CartesianGrid strokeDasharray="3 3" vertical={false} stroke="#f1f1f1" />
                        <XAxis 
                          dataKey="name" 
                          axisLine={false} 
                          tickLine={false} 
                          tick={{ fontSize: 10, fontWeight: 600, fill: '#a1a1aa' }} 
                          dy={10}
                        />
                        <YAxis 
                          domain={[0, 5]} 
                          axisLine={false} 
                          tickLine={false} 
                          tick={{ fontSize: 10, fontWeight: 600, fill: '#a1a1aa' }} 
                        />
                        <Tooltip 
                          contentStyle={{ borderRadius: '12px', border: 'none', boxShadow: '0 10px 15px -3px rgb(0 0 0 / 0.1)', fontSize: '12px', fontWeight: 'bold' }}
                        />
                        <Area 
                          type="monotone" 
                          dataKey="prevScore" 
                          stroke="#e4e4e7" 
                          strokeWidth={2} 
                          fill="transparent"
                          strokeDasharray="5 5"
                        />
                        <Area 
                          type="monotone" 
                          dataKey="score" 
                          stroke="#f43f5e" 
                          strokeWidth={3} 
                          fillOpacity={1} 
                          fill="url(#colorScore)" 
                        />
                      </AreaChart>
                    </ResponsiveContainer>
                  </div>
                </div>

                {/* Issue Distribution */}
                <div className="lg:col-span-4 bg-white p-6 rounded-3xl border border-zinc-200 shadow-sm space-y-6">
                  <h3 className="text-sm font-black tracking-tight flex items-center gap-2 uppercase">
                    <PieChartIcon size={16} className="text-rose-500" />
                    Issue Distribution
                  </h3>
                  <div className="h-[250px] w-full">
                    <ResponsiveContainer width="100%" height="100%">
                      <PieChart>
                        <Pie
                          data={issueData}
                          cx="50%"
                          cy="50%"
                          innerRadius={60}
                          outerRadius={80}
                          paddingAngle={5}
                          dataKey="value"
                        >
                          {issueData.map((entry, index) => (
                            <Cell key={`cell-${index}`} fill={entry.color} />
                          ))}
                        </Pie>
                        <Tooltip 
                          contentStyle={{ borderRadius: '12px', border: 'none', boxShadow: '0 10px 15px -3px rgb(0 0 0 / 0.1)', fontSize: '12px', fontWeight: 'bold' }}
                        />
                      </PieChart>
                    </ResponsiveContainer>
                  </div>
                  <div className="space-y-2">
                    {issueData.map((item, i) => (
                      <div key={i} className="flex items-center justify-between">
                        <div className="flex items-center gap-2">
                          <div className="w-2 h-2 rounded-full" style={{ backgroundColor: item.color }}></div>
                          <span className="text-[10px] font-bold text-zinc-500 uppercase">{item.name}</span>
                        </div>
                        <span className="text-[10px] font-black">{item.value}%</span>
                      </div>
                    ))}
                  </div>
                </div>

                {/* Detailed Audit Log Table */}
                <div className="lg:col-span-12 bg-white rounded-3xl border border-zinc-200 shadow-sm overflow-hidden">
                  <div className="p-6 border-b border-zinc-100 flex items-center justify-between">
                    <h3 className="text-sm font-black tracking-tight flex items-center gap-2 uppercase">
                      <Clock size={16} className="text-zinc-400" />
                      Detailed Audit History
                    </h3>
                    <button className="text-[10px] font-bold text-rose-600 hover:underline">VIEW FULL LOG</button>
                  </div>
                  <div className="overflow-x-auto">
                    <table className="w-full text-left border-collapse">
                      <thead>
                        <tr className="bg-zinc-50/50">
                          <th className="px-6 py-4 text-[10px] font-bold text-zinc-400 uppercase tracking-widest">Date</th>
                          <th className="px-6 py-4 text-[10px] font-bold text-zinc-400 uppercase tracking-widest">Location</th>
                          <th className="px-6 py-4 text-[10px] font-bold text-zinc-400 uppercase tracking-widest">Evidence</th>
                          <th className="px-6 py-4 text-[10px] font-bold text-zinc-400 uppercase tracking-widest">Score</th>
                          <th className="px-6 py-4 text-[10px] font-bold text-zinc-400 uppercase tracking-widest">Verification</th>
                          <th className="px-6 py-4 text-[10px] font-bold text-zinc-400 uppercase tracking-widest">Status</th>
                          <th className="px-6 py-4 text-[10px] font-bold text-zinc-400 uppercase tracking-widest">Issues</th>
                          <th className="px-6 py-4 text-[10px] font-bold text-zinc-400 uppercase tracking-widest">Action</th>
                        </tr>
                      </thead>
                      <tbody className="divide-y divide-zinc-100">
                        {detailedReports.map((report) => (
                          <tr key={report.id} className="hover:bg-zinc-50/50 transition-colors">
                            <td className="px-6 py-4 text-xs font-medium text-zinc-500">{report.date}</td>
                            <td className="px-6 py-4 text-xs font-bold">{report.location}</td>
                            <td className="px-6 py-4">
                              {report.isCleanupLog ? (
                                <div className="flex items-center gap-1">
                                  <div className="w-8 h-8 rounded-lg overflow-hidden border border-zinc-100 relative group/img">
                                    <img src={report.beforeImageUrl} alt="Before" className="w-full h-full object-cover" referrerPolicy="no-referrer" />
                                    <div className="absolute inset-0 bg-black/40 opacity-0 group-hover/img:opacity-100 flex items-center justify-center transition-opacity">
                                      <span className="text-[6px] text-white font-black">BEFORE</span>
                                    </div>
                                  </div>
                                  <ArrowRight size={10} className="text-zinc-300" />
                                  <div className="w-8 h-8 rounded-lg overflow-hidden border border-emerald-100 relative group/img">
                                    <img src={report.afterImageUrl} alt="After" className="w-full h-full object-cover" referrerPolicy="no-referrer" />
                                    <div className="absolute inset-0 bg-emerald-600/40 opacity-0 group-hover/img:opacity-100 flex items-center justify-center transition-opacity">
                                      <span className="text-[6px] text-white font-black">AFTER</span>
                                    </div>
                                  </div>
                                </div>
                              ) : (
                                <div className="w-8 h-8 rounded-lg overflow-hidden border border-zinc-100">
                                  <img src={report.imageUrl || report.beforeImageUrl} alt="Audit" className="w-full h-full object-cover" referrerPolicy="no-referrer" />
                                </div>
                              )}
                            </td>
                            <td className="px-6 py-4">
                              <span className={`text-xs font-black ${getScoreColor(report.score)}`}>{report.score}</span>
                            </td>
                            <td className="px-6 py-4">
                              <div className="flex items-center gap-1.5">
                                {report.verified ? (
                                  <CheckCircle2 size={12} className="text-emerald-500" />
                                ) : (
                                  <XCircle size={12} className="text-rose-500" />
                                )}
                                <span className={`text-[10px] font-bold ${report.verified ? 'text-emerald-600' : 'text-rose-600'}`}>
                                  {report.isCleanupLog ? 'ESG VERIFIED' : (report.verified ? 'AUTHENTIC' : 'FRAUD ALERT')}
                                </span>
                              </div>
                            </td>
                            <td className="px-6 py-4">
                              <span className={`px-2 py-0.5 rounded text-[9px] font-bold uppercase ${getScoreBg(report.score)} ${getScoreColor(report.score)}`}>
                                {report.status}
                              </span>
                            </td>
                            <td className="px-6 py-4 text-xs font-medium text-zinc-500">{report.issues} detected</td>
                            <td className="px-6 py-4">
                              <button className="p-1.5 hover:bg-zinc-100 rounded-lg text-zinc-400 hover:text-rose-600 transition-all">
                                <Info size={14} />
                              </button>
                            </td>
                          </tr>
                        ))}
                      </tbody>
                    </table>
                  </div>
                </div>

                {/* Performance Ranking */}
                <div className="lg:col-span-12 bg-white p-6 rounded-3xl border border-zinc-200 shadow-sm space-y-6">
                  <div className="flex items-center justify-between">
                    <h3 className="text-sm font-black tracking-tight flex items-center gap-2 uppercase">
                      <Star size={16} className="text-amber-500" />
                      Location Performance Ranking
                    </h3>
                    <button className="text-[10px] font-bold text-rose-600 hover:underline">VIEW ALL LOCATIONS</button>
                  </div>
                  <div className="h-[300px] w-full">
                    <ResponsiveContainer width="100%" height="100%">
                      <BarChart data={performanceData} layout="vertical">
                        <CartesianGrid strokeDasharray="3 3" horizontal={false} stroke="#f1f1f1" />
                        <XAxis type="number" domain={[0, 5]} hide />
                        <YAxis 
                          dataKey="name" 
                          type="category" 
                          axisLine={false} 
                          tickLine={false} 
                          tick={{ fontSize: 10, fontWeight: 700, fill: '#3f3f46' }} 
                          width={100}
                        />
                        <Tooltip 
                          cursor={{ fill: '#f8fafc' }}
                          contentStyle={{ borderRadius: '12px', border: 'none', boxShadow: '0 10px 15px -3px rgb(0 0 0 / 0.1)', fontSize: '12px', fontWeight: 'bold' }}
                        />
                        <Bar 
                          dataKey="score" 
                          fill="#f43f5e" 
                          radius={[0, 4, 4, 0]} 
                          barSize={20}
                        >
                          {performanceData.map((entry, index) => (
                            <Cell 
                              key={`cell-${index}`} 
                              fill={Number(entry.score) >= 4.5 ? '#10b981' : Number(entry.score) >= 4 ? '#34d399' : '#f43f5e'} 
                            />
                          ))}
                        </Bar>
                      </BarChart>
                    </ResponsiveContainer>
                  </div>
                </div>
              </div>
            </motion.div>
          ) : activeTab === 'reports' ? (
            <motion.div 
              key="reports"
              initial={{ opacity: 0, y: 10 }}
              animate={{ opacity: 1, y: 0 }}
              exit={{ opacity: 0, y: -10 }}
              className="space-y-8"
            >
              <div className="flex flex-col md:flex-row justify-between items-start md:items-center gap-4">
                <div>
                  <h2 className="text-2xl font-black tracking-tight flex items-center gap-2">
                    <MessageSquare size={24} className="text-rose-600" />
                    REVIEWS & REPORTS
                  </h2>
                  <p className="text-sm text-zinc-500">Citizen complaints and feedback for {currentDivision.name} Post Offices</p>
                </div>
                <div className="flex items-center gap-2 bg-zinc-100 p-1 rounded-xl">
                  <button 
                    onClick={() => setReportView('complaints')}
                    className={`px-4 py-2 rounded-lg text-[10px] font-black uppercase tracking-widest transition-all ${
                      reportView === 'complaints' ? 'bg-white text-rose-600 shadow-sm' : 'text-zinc-400 hover:text-zinc-600'
                    }`}
                  >
                    Complaints
                  </button>
                  <button 
                    onClick={() => setReportView('multimedia')}
                    className={`px-4 py-2 rounded-lg text-[10px] font-black uppercase tracking-widest transition-all ${
                      reportView === 'multimedia' ? 'bg-white text-rose-600 shadow-sm' : 'text-zinc-400 hover:text-zinc-600'
                    }`}
                  >
                    Multimedia
                  </button>
                  <button 
                    onClick={() => setReportView('reviews')}
                    className={`px-4 py-2 rounded-lg text-[10px] font-black uppercase tracking-widest transition-all ${
                      reportView === 'reviews' ? 'bg-white text-rose-600 shadow-sm' : 'text-zinc-400 hover:text-zinc-600'
                    }`}
                  >
                    Cleanup Reviews
                  </button>
                </div>
                {userProfile?.role === 'user' && (
                  <button 
                    onClick={() => setShowQuickReport(!showQuickReport)}
                    className="px-6 py-2.5 bg-zinc-900 text-white rounded-xl text-[10px] font-black uppercase tracking-widest hover:bg-zinc-800 transition-all shadow-lg flex items-center gap-2"
                  >
                    {showQuickReport ? <XCircle size={14} /> : <Plus size={14} />}
                    {showQuickReport ? 'CANCEL' : 'FILE NEW COMPLAINT'}
                  </button>
                )}
              </div>

              <AnimatePresence>
                {showQuickReport && (
                  <motion.div
                    initial={{ opacity: 0, height: 0 }}
                    animate={{ opacity: 1, height: 'auto' }}
                    exit={{ opacity: 0, height: 0 }}
                    className="overflow-hidden"
                  >
                    <div className="bg-white rounded-[32px] border border-zinc-200 p-8 shadow-sm space-y-6">
                      <div className="flex justify-between items-center">
                        <h3 className="text-lg font-black tracking-tight uppercase">Quick Complaint Submission</h3>
                        <div className="flex items-center gap-2">
                          <label className="text-[10px] font-bold text-zinc-400 uppercase tracking-widest">Location</label>
                          <select 
                            value={selectedLocation.id}
                            onChange={(e) => setSelectedLocation(filteredPostOffices.find(po => po.id === e.target.value)!)}
                            className="text-[10px] font-bold bg-zinc-50 border border-zinc-200 rounded px-2 py-1 focus:outline-none focus:ring-2 focus:ring-rose-500/20"
                          >
                            {filteredPostOffices.map(po => (
                              <option key={po.id} value={po.id}>{po.name}</option>
                            ))}
                          </select>
                        </div>
                      </div>

                      <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
                        <div className="space-y-2">
                          <label className="text-[10px] font-bold text-zinc-400 uppercase tracking-widest">Description (Text)</label>
                          <textarea 
                            value={complaintDescription}
                            onChange={(e) => setComplaintDescription(e.target.value)}
                            placeholder="Describe the issue... (Optional if media provided)"
                            className="w-full p-4 bg-zinc-50 border border-zinc-200 rounded-2xl text-xs focus:outline-none focus:ring-2 focus:ring-rose-500/20 min-h-[120px] resize-none"
                          />
                        </div>
                        <div className="space-y-4">
                          <h4 className="text-[10px] font-black text-zinc-400 uppercase tracking-widest border-b border-zinc-100 pb-2">Multimedia Evidence</h4>
                          <div className="space-y-2">
                            <label className="text-[10px] font-bold text-zinc-400 uppercase tracking-widest">Evidence (Photo)</label>
                          <div 
                            onClick={() => {
                              const input = document.createElement('input');
                              input.type = 'file';
                              input.accept = 'image/*';
                              input.onchange = (e: any) => {
                                const file = e.target.files?.[0];
                                if (file) {
                                  const reader = new FileReader();
                                  reader.onload = async (e) => {
                                    const resized = await resizeImage(e.target?.result as string);
                                    setImage(resized);
                                  };
                                  reader.readAsDataURL(file);
                                }
                              };
                              input.click();
                            }}
                            className="aspect-video rounded-2xl border-2 border-dashed border-zinc-200 bg-zinc-50 flex flex-col items-center justify-center gap-2 cursor-pointer hover:border-rose-300 hover:bg-rose-50/30 transition-all group relative overflow-hidden"
                          >
                            {image ? (
                              <>
                                <img src={image} alt="Preview" className="w-full h-full object-cover" referrerPolicy="no-referrer" />
                                <div className="absolute inset-0 bg-black/20 opacity-0 group-hover:opacity-100 flex items-center justify-center transition-opacity">
                                  <span className="text-[10px] text-white font-black uppercase">Change Photo</span>
                                </div>
                              </>
                            ) : (
                              <>
                                <Camera size={24} className="text-zinc-400 group-hover:scale-110 transition-transform" />
                                <span className="text-[10px] font-bold text-zinc-500">UPLOAD PHOTO</span>
                              </>
                            )}
                          </div>
                        </div>
                        <div className="space-y-2">
                          <label className="text-[10px] font-bold text-zinc-400 uppercase tracking-widest">Video / Document</label>
                          <div className="grid grid-cols-1 gap-2">
                            <button 
                              onClick={() => {
                                const input = document.createElement('input');
                                input.type = 'file';
                                input.accept = 'video/*';
                                input.onchange = (e: any) => {
                                  const file = e.target.files?.[0];
                                  if (file) setVideo(`video_uploaded_${file.name}`);
                                };
                                input.click();
                              }}
                              className={`flex items-center gap-3 p-3 rounded-xl border-2 border-dashed transition-all ${video ? 'border-emerald-500 bg-emerald-50 text-emerald-600' : 'border-zinc-200 bg-zinc-50 text-zinc-400 hover:border-rose-300 hover:bg-rose-50/30'}`}
                            >
                              <Play size={16} />
                              <span className="text-[10px] font-bold uppercase">{video ? 'VIDEO ADDED' : 'ADD VIDEO'}</span>
                            </button>
                            <button 
                              onClick={() => {
                                const input = document.createElement('input');
                                input.type = 'file';
                                input.accept = '.pdf,.doc,.docx,.txt';
                                input.onchange = (e: any) => {
                                  const file = e.target.files?.[0];
                                  if (file) setDocumentFile(`doc_uploaded_${file.name}`);
                                };
                                input.click();
                              }}
                              className={`flex items-center gap-3 p-3 rounded-xl border-2 border-dashed transition-all ${documentFile ? 'border-emerald-500 bg-emerald-50 text-emerald-600' : 'border-zinc-200 bg-zinc-50 text-zinc-400 hover:border-rose-300 hover:bg-rose-50/30'}`}
                            >
                              <FileText size={16} />
                              <span className="text-[10px] font-bold uppercase">{documentFile ? 'DOC ADDED' : 'ADD LETTER'}</span>
                            </button>
                          </div>
                        </div>
                      </div>
                    </div>

                    <div className="flex justify-end gap-3">
                        <button 
                          onClick={() => {
                            setShowQuickReport(false);
                            setImage(null);
                            setComplaintDescription('');
                          }}
                          className="px-6 py-3 text-xs font-bold text-zinc-500 hover:text-zinc-700 transition-colors"
                        >
                          CANCEL
                        </button>
                        <button 
                          onClick={async () => {
                            await submitComplaint();
                            setShowQuickReport(false);
                          }}
                          disabled={isSubmittingComplaint || (!image && !complaintDescription && !video && !documentFile)}
                          className="px-8 py-3 bg-rose-600 text-white rounded-xl text-xs font-black uppercase tracking-widest hover:bg-rose-500 transition-all shadow-lg shadow-rose-200 disabled:opacity-50 flex items-center gap-2"
                        >
                          {isSubmittingComplaint ? <RefreshCw size={14} className="animate-spin" /> : <Send size={14} />}
                          SUBMIT COMPLAINT
                        </button>
                      </div>
                    </div>
                  </motion.div>
                )}
              </AnimatePresence>

              <div className="grid grid-cols-1 lg:grid-cols-12 gap-8">
                <div className="lg:col-span-12 space-y-6">
                  {reportView !== 'reviews' ? (
                    <div className="grid grid-cols-1 md:grid-cols-2 xl:grid-cols-3 gap-6">
                      {combinedReports
                        .filter(c => reportView === 'multimedia' ? (c.imageUrl || c.videoUrl || c.documentUrl) : true)
                        .map((complaint) => (
                        <div key={complaint.id} className="bg-white rounded-3xl border border-zinc-200 shadow-sm overflow-hidden flex flex-col group hover:shadow-lg transition-all">
                          <div className="aspect-video relative overflow-hidden bg-zinc-100">
                            {complaint.imageUrl ? (
                              <img 
                                src={complaint.imageUrl} 
                                alt="Complaint" 
                                className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-500"
                                referrerPolicy="no-referrer"
                              />
                            ) : complaint.videoUrl ? (
                              <div className="w-full h-full flex flex-col items-center justify-center bg-zinc-900 text-white gap-2">
                                <Play size={32} className="group-hover:scale-110 transition-transform" />
                                <span className="text-[10px] font-bold uppercase">Video Evidence</span>
                              </div>
                            ) : complaint.documentUrl ? (
                              <div className="w-full h-full flex flex-col items-center justify-center bg-blue-50 text-blue-600 gap-2">
                                <FileText size={32} className="group-hover:scale-110 transition-transform" />
                                <span className="text-[10px] font-bold uppercase">Document/Letter</span>
                              </div>
                            ) : (
                              <div className="w-full h-full flex flex-col items-center justify-center text-zinc-300 gap-2">
                                <MessageSquare size={32} />
                                <span className="text-[10px] font-bold uppercase">Text-only Report</span>
                              </div>
                            )}
                            <div className="absolute top-3 left-3 flex gap-2">
                              <span className={`px-2 py-1 rounded-full text-[9px] font-black uppercase tracking-widest ${
                                complaint.status === 'resolved' ? 'bg-emerald-500 text-white' : 'bg-amber-500 text-white'
                              }`}>
                                {complaint.status}
                              </span>
                              {(complaint.videoUrl || complaint.documentUrl) && (
                                <span className="px-2 py-1 bg-white/90 backdrop-blur-md text-zinc-900 text-[9px] font-black uppercase tracking-widest rounded-full flex items-center gap-1">
                                  {complaint.videoUrl ? <Play size={8} fill="currentColor" /> : <FileText size={8} />}
                                  {complaint.videoUrl ? 'VIDEO' : 'DOC'}
                                </span>
                              )}
                            </div>
                            
                            <button 
                              onClick={() => setSelectedComplaint(complaint)}
                              className="absolute inset-0 bg-black/40 opacity-0 group-hover:opacity-100 flex items-center justify-center transition-opacity z-10"
                            >
                              <div className="bg-white text-zinc-900 px-4 py-2 rounded-xl text-[10px] font-black uppercase tracking-widest flex items-center gap-2">
                                <Eye size={14} /> VIEW DETAILS
                              </div>
                            </button>
                          </div>
                          <div className="p-5 flex-1 flex flex-col space-y-4">
                            <div className="flex justify-between items-start">
                              <div>
                                <h4 className="text-sm font-black text-zinc-900">{complaint.location}</h4>
                                <p className="text-[10px] text-zinc-400 font-bold uppercase tracking-widest flex items-center gap-1 mt-1">
                                  <Clock3 size={10} /> {complaint.date?.toDate?.()?.toLocaleDateString() || 'Recently'}
                                </p>
                              </div>
                            </div>
                            <p className="text-xs text-zinc-600 leading-relaxed flex-1 italic">
                              "{complaint.description}"
                            </p>
                            <div className="pt-4 border-t border-zinc-50 flex items-center justify-between">
                              <div className="flex items-center gap-2">
                                <div className="w-6 h-6 rounded-full bg-zinc-100 flex items-center justify-center text-[8px] font-bold text-zinc-400">
                                  {complaint.authorName?.charAt(0)}
                                </div>
                                <span className="text-[10px] font-bold text-zinc-500">{complaint.authorName}</span>
                              </div>
                              {(userProfile?.role === 'admin' || userProfile?.role === 'worker') && complaint.status === 'pending' && (
                                <button 
                                  onClick={() => setResolvingComplaint(complaint)}
                                  className="px-3 py-1.5 bg-emerald-50 text-emerald-600 rounded-lg text-[10px] font-black uppercase tracking-widest hover:bg-emerald-100 transition-all flex items-center gap-2"
                                >
                                  <CheckCircle size={12} /> RESOLVE WITH EVIDENCE
                                </button>
                              )}
                              {complaint.status === 'resolved' && (
                                <div className="flex items-center gap-1 text-emerald-600">
                                  <CheckCircle size={12} />
                                  <span className="text-[10px] font-black uppercase tracking-widest">Resolved</span>
                                </div>
                              )}
                            </div>
                            {complaint.status === 'resolved' && complaint.resolvedBy && (
                              <p className="text-[9px] text-zinc-400 font-medium text-right">
                                Resolved by {complaint.resolvedBy}
                              </p>
                            )}
                          </div>
                        </div>
                      ))}
                      {complaints.length === 0 && (
                        <div className="col-span-full py-20 text-center border-2 border-dashed border-zinc-200 rounded-3xl">
                          <MessageSquare size={48} className="mx-auto text-zinc-200 mb-4" />
                          <h3 className="text-lg font-bold text-zinc-400">No complaints reported yet</h3>
                          <p className="text-xs text-zinc-500 mt-2">Citizens can report cleanliness issues here.</p>
                        </div>
                      )}
                    </div>
                  ) : (
                    <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
                      {audits.filter(a => a.isCleanupLog).map((review) => (
                        <div key={review.id} className="bg-white rounded-[40px] border border-zinc-200 shadow-sm overflow-hidden flex flex-col group hover:shadow-xl transition-all duration-500">
                          <div className="grid grid-cols-2 gap-1 p-1 bg-zinc-50">
                            <div className="aspect-square relative overflow-hidden rounded-[32px]">
                              <img 
                                src={review.beforeImageUrl} 
                                alt="Before" 
                                className="w-full h-full object-cover"
                                referrerPolicy="no-referrer"
                              />
                              <div className="absolute top-4 left-4">
                                <span className="px-3 py-1 bg-black/60 backdrop-blur-md text-white text-[8px] font-black uppercase tracking-widest rounded-full">Before</span>
                              </div>
                            </div>
                            <div className="aspect-square relative overflow-hidden rounded-[32px]">
                              <img 
                                src={review.afterImageUrl} 
                                alt="After" 
                                className="w-full h-full object-cover"
                                referrerPolicy="no-referrer"
                              />
                              <div className="absolute top-4 left-4">
                                <span className="px-3 py-1 bg-emerald-500/80 backdrop-blur-md text-white text-[8px] font-black uppercase tracking-widest rounded-full">After</span>
                              </div>
                              <div className="absolute inset-0 bg-emerald-500/10 opacity-0 group-hover:opacity-100 transition-opacity pointer-events-none" />
                            </div>
                          </div>
                          <div className="p-8 space-y-4">
                            <div className="flex justify-between items-start">
                              <div>
                                <div className="flex items-center gap-2 mb-1">
                                  <span className="px-2 py-0.5 bg-emerald-100 text-emerald-600 text-[8px] font-black uppercase tracking-widest rounded">Cleanup Verified</span>
                                  <span className="text-[10px] text-zinc-400 font-bold">{review.date}</span>
                                </div>
                                <h4 className="text-lg font-black text-zinc-900 leading-tight">{review.location}</h4>
                              </div>
                              <div className="flex items-center gap-0.5">
                                {[...Array(5)].map((_, i) => (
                                  <Star key={i} size={12} className="fill-amber-400 text-amber-400" />
                                ))}
                              </div>
                            </div>
                            <p className="text-sm text-zinc-600 leading-relaxed italic">
                              {review.description || "The area has been thoroughly cleaned and restored to optimal standards."}
                            </p>
                            <div className="pt-6 border-t border-zinc-50 flex items-center justify-between">
                              <div className="flex items-center gap-3">
                                <div className="w-10 h-10 rounded-2xl bg-zinc-100 flex items-center justify-center text-xs font-black text-zinc-400 border border-zinc-200">
                                  {review.authorName?.charAt(0) || 'W'}
                                </div>
                                <div>
                                  <p className="text-[10px] font-black text-zinc-900 uppercase tracking-tight">Verified By</p>
                                  <p className="text-xs text-zinc-500 font-medium">{review.authorName || 'Audit Team'}</p>
                                </div>
                              </div>
                              <div className="flex items-center gap-2 px-4 py-2 bg-emerald-50 rounded-2xl">
                                <ShieldCheck size={16} className="text-emerald-600" />
                                <span className="text-[10px] font-black text-emerald-700 uppercase tracking-widest">ESG SECURE</span>
                              </div>
                            </div>
                          </div>
                        </div>
                      ))}
                      {audits.filter(a => a.isCleanupLog).length === 0 && (
                        <div className="col-span-full py-20 text-center border-2 border-dashed border-zinc-200 rounded-[40px]">
                          <Sparkles size={48} className="mx-auto text-zinc-200 mb-4" />
                          <h3 className="text-lg font-bold text-zinc-400">No cleanup reviews yet</h3>
                          <p className="text-xs text-zinc-500 mt-2">When issues are resolved, they will appear here as success stories.</p>
                        </div>
                      )}
                    </div>
                  )}
                </div>
              </div>

              {/* Multimedia Detail Modal */}
              <AnimatePresence>
                {selectedComplaint && (
                  <motion.div
                    initial={{ opacity: 0 }}
                    animate={{ opacity: 1 }}
                    exit={{ opacity: 0 }}
                    className="fixed inset-0 bg-zinc-900/90 backdrop-blur-xl z-[100] flex items-center justify-center p-4 md:p-8"
                  >
                    <motion.div
                      initial={{ scale: 0.9, y: 20 }}
                      animate={{ scale: 1, y: 0 }}
                      exit={{ scale: 0.9, y: 20 }}
                      className="bg-white w-full max-w-5xl rounded-[40px] overflow-hidden shadow-2xl flex flex-col md:flex-row max-h-[90vh]"
                    >
                      {/* Media Section */}
                      <div className="md:w-3/5 bg-zinc-100 relative min-h-[300px] flex items-center justify-center">
                        {selectedComplaint.imageUrl ? (
                          <img 
                            src={selectedComplaint.imageUrl} 
                            alt="Evidence" 
                            className="w-full h-full object-contain"
                            referrerPolicy="no-referrer"
                          />
                        ) : selectedComplaint.videoUrl ? (
                          <div className="w-full h-full flex flex-col items-center justify-center bg-zinc-900 text-white p-12 text-center gap-6">
                            <div className="w-24 h-24 rounded-full bg-rose-600 flex items-center justify-center shadow-lg shadow-rose-600/40">
                              <Play size={40} fill="currentColor" />
                            </div>
                            <div>
                              <h3 className="text-xl font-black uppercase tracking-tight mb-2">Video Evidence Attached</h3>
                              <p className="text-zinc-400 text-sm max-w-xs mx-auto">This report includes a video clip of the reported issue at {selectedComplaint.location}.</p>
                            </div>
                            <button className="px-8 py-3 bg-white text-zinc-900 rounded-2xl text-xs font-black uppercase tracking-widest hover:bg-zinc-100 transition-all">
                              Download Video
                            </button>
                          </div>
                        ) : selectedComplaint.documentUrl ? (
                          <div className="w-full h-full flex flex-col items-center justify-center bg-blue-50 text-blue-600 p-12 text-center gap-6">
                            <div className="w-24 h-24 rounded-full bg-blue-600 text-white flex items-center justify-center shadow-lg shadow-blue-600/40">
                              <FileText size={40} />
                            </div>
                            <div>
                              <h3 className="text-xl font-black uppercase tracking-tight mb-2">Formal Letter Attached</h3>
                              <p className="text-blue-400 text-sm max-w-xs mx-auto">A formal complaint document has been submitted for review.</p>
                            </div>
                            <button className="px-8 py-3 bg-blue-600 text-white rounded-2xl text-xs font-black uppercase tracking-widest hover:bg-blue-700 transition-all">
                              View Document
                            </button>
                          </div>
                        ) : (
                          <div className="w-full h-full flex flex-col items-center justify-center text-zinc-300 gap-4">
                            <MessageSquare size={64} />
                            <span className="text-sm font-bold uppercase tracking-widest">No Media Attached</span>
                          </div>
                        )}
                        
                        <button 
                          onClick={() => setSelectedComplaint(null)}
                          className="absolute top-6 left-6 w-12 h-12 bg-white/90 backdrop-blur-md rounded-2xl flex items-center justify-center text-zinc-900 shadow-lg hover:bg-white transition-all z-20"
                        >
                          <X size={24} />
                        </button>
                      </div>

                      {/* Info Section */}
                      <div className="md:w-2/5 p-8 md:p-12 flex flex-col bg-white overflow-y-auto">
                        <div className="flex-1 space-y-8">
                          <div className="space-y-2">
                            <div className="flex items-center gap-2">
                              <span className={`px-3 py-1 rounded-full text-[10px] font-black uppercase tracking-widest ${
                                selectedComplaint.status === 'resolved' ? 'bg-emerald-500 text-white' : 'bg-amber-500 text-white'
                              }`}>
                                {selectedComplaint.status}
                              </span>
                              <span className="text-[10px] text-zinc-400 font-bold uppercase tracking-widest">{selectedComplaint.date}</span>
                            </div>
                            <h2 className="text-3xl font-black text-zinc-900 tracking-tight leading-none">{selectedComplaint.location}</h2>
                          </div>

                          <div className="space-y-4">
                            <h4 className="text-[10px] font-black text-zinc-400 uppercase tracking-widest border-b border-zinc-100 pb-2">Description</h4>
                            <p className="text-zinc-600 leading-relaxed">
                              {selectedComplaint.description || "No detailed description provided for this report."}
                            </p>
                          </div>

                          <div className="space-y-4">
                            <h4 className="text-[10px] font-black text-zinc-400 uppercase tracking-widest border-b border-zinc-100 pb-2">Submitted By</h4>
                            <div className="flex items-center gap-4">
                              <div className="w-12 h-12 rounded-2xl bg-rose-50 text-rose-600 flex items-center justify-center text-sm font-black border border-rose-100">
                                {selectedComplaint.authorName?.charAt(0) || 'U'}
                              </div>
                              <div>
                                <p className="text-sm font-black text-zinc-900">{selectedComplaint.authorName || 'Anonymous Citizen'}</p>
                                <p className="text-xs text-zinc-500 font-medium">Verified Citizen Account</p>
                              </div>
                            </div>
                          </div>
                        </div>

                        <div className="pt-8 mt-8 border-t border-zinc-100">
                          <button 
                            onClick={() => setSelectedComplaint(null)}
                            className="w-full py-4 bg-zinc-900 text-white rounded-2xl font-black uppercase tracking-widest text-xs hover:bg-zinc-800 transition-all"
                          >
                            Close Details
                          </button>
                        </div>
                      </div>
                    </motion.div>
                  </motion.div>
                )}
              </AnimatePresence>

              <AnimatePresence>
                {resolvingComplaint && (
                  <div className="fixed inset-0 z-[100] flex items-center justify-center p-4">
                    <motion.div 
                      initial={{ opacity: 0 }}
                      animate={{ opacity: 1 }}
                      exit={{ opacity: 0 }}
                      onClick={() => setResolvingComplaint(null)}
                      className="absolute inset-0 bg-zinc-900/60 backdrop-blur-sm"
                    />
                    <motion.div 
                      initial={{ opacity: 0, scale: 0.9, y: 20 }}
                      animate={{ opacity: 1, scale: 1, y: 0 }}
                      exit={{ opacity: 0, scale: 0.9, y: 20 }}
                      className="relative w-full max-w-lg bg-white rounded-[40px] shadow-2xl overflow-hidden border border-zinc-200"
                    >
                      <div className="p-8 space-y-6">
                        <div className="flex justify-between items-start">
                          <div>
                            <h3 className="text-xl font-black tracking-tight uppercase">Submit Cleanup Evidence</h3>
                            <p className="text-xs text-zinc-500 mt-1">Upload an 'After' image for ESG accountability</p>
                          </div>
                          <button 
                            onClick={() => setResolvingComplaint(null)}
                            className="p-2 hover:bg-zinc-100 rounded-full transition-colors"
                          >
                            <XCircle size={24} className="text-zinc-400" />
                          </button>
                        </div>

                        <div className="grid grid-cols-2 gap-4">
                          <div className="space-y-2">
                            <p className="text-[10px] font-bold text-zinc-400 uppercase tracking-widest">Before (Citizen Report)</p>
                            <div className="aspect-square rounded-2xl overflow-hidden border border-zinc-100">
                              <img src={resolvingComplaint.imageUrl} alt="Before" className="w-full h-full object-cover" referrerPolicy="no-referrer" />
                            </div>
                          </div>
                          <div className="space-y-2">
                            <p className="text-[10px] font-bold text-zinc-400 uppercase tracking-widest">After (Cleanup Evidence)</p>
                            <div className="aspect-square rounded-2xl overflow-hidden border-2 border-dashed border-zinc-200 bg-zinc-50 flex items-center justify-center relative">
                              {afterImage ? (
                                <>
                                  <img src={afterImage} alt="After" className="w-full h-full object-cover" referrerPolicy="no-referrer" />
                                  <button 
                                    onClick={() => setAfterImage(null)}
                                    className="absolute top-2 right-2 p-1 bg-white/80 backdrop-blur-md rounded-full shadow-sm"
                                  >
                                    <XCircle size={16} className="text-rose-600" />
                                  </button>
                                </>
                              ) : (
                                <button 
                                  onClick={() => {
                                    const input = document.createElement('input');
                                    input.type = 'file';
                                    input.accept = 'image/*';
                                    input.onchange = (e: any) => {
                                      const file = e.target.files?.[0];
                                      if (file) {
                                        const reader = new FileReader();
                                        reader.onload = async (e) => {
                                          const resized = await resizeImage(e.target?.result as string);
                                          setAfterImage(resized);
                                        };
                                        reader.readAsDataURL(file);
                                      }
                                    };
                                    input.click();
                                  }}
                                  className="flex flex-col items-center gap-2 text-zinc-400 hover:text-rose-600 transition-colors"
                                >
                                  <Camera size={24} />
                                  <span className="text-[10px] font-bold">UPLOAD PHOTO</span>
                                </button>
                              )}
                            </div>
                          </div>
                        </div>

                        <button 
                          onClick={() => resolveComplaint(resolvingComplaint.id, afterImage!)}
                          disabled={!afterImage || isResolving}
                          className="w-full py-4 bg-emerald-600 text-white rounded-2xl font-bold flex items-center justify-center gap-2 hover:bg-emerald-500 transition-all shadow-lg shadow-emerald-200 disabled:opacity-50"
                        >
                          {isResolving ? <RefreshCw size={18} className="animate-spin" /> : <CheckCircle size={18} />}
                          LOG CLEANUP EVIDENCE
                        </button>
                      </div>
                    </motion.div>
                  </div>
                )}
              </AnimatePresence>
            </motion.div>
          ) : activeTab === 'users' ? (
            <motion.div 
              key="users"
              initial={{ opacity: 0, y: 10 }}
              animate={{ opacity: 1, y: 0 }}
              exit={{ opacity: 0, y: -10 }}
              className="space-y-8"
            >
              <div className="flex flex-col md:flex-row justify-between items-start md:items-center gap-4">
                <div>
                  <h2 className="text-2xl font-black tracking-tight flex items-center gap-2">
                    <UserCog size={24} className="text-rose-600" />
                    USER MANAGEMENT
                  </h2>
                  <p className="text-sm text-zinc-500">Manage roles and permissions for {currentDivision.name} Swachhata Monitor</p>
                </div>
                <button 
                  onClick={() => setShowAddUserModal(true)}
                  className="px-6 py-2.5 bg-zinc-900 text-white rounded-xl text-[10px] font-black uppercase tracking-widest hover:bg-zinc-800 transition-all shadow-lg flex items-center gap-2"
                >
                  <UserPlus size={14} /> ADD NEW USER
                </button>
              </div>

              <AnimatePresence>
                {showAddUserModal && (
                  <div className="fixed inset-0 z-[100] flex items-center justify-center p-4">
                    <motion.div 
                      initial={{ opacity: 0 }}
                      animate={{ opacity: 1 }}
                      exit={{ opacity: 0 }}
                      onClick={() => setShowAddUserModal(false)}
                      className="absolute inset-0 bg-zinc-900/60 backdrop-blur-sm"
                    />
                    <motion.div 
                      initial={{ opacity: 0, scale: 0.9, y: 20 }}
                      animate={{ opacity: 1, scale: 1, y: 0 }}
                      exit={{ opacity: 0, scale: 0.9, y: 20 }}
                      className="relative w-full max-w-md bg-white rounded-[40px] shadow-2xl overflow-hidden border border-zinc-200"
                    >
                      <form onSubmit={handleAddUser} className="p-8 space-y-6">
                        <div className="flex justify-between items-start">
                          <div>
                            <h3 className="text-xl font-black tracking-tight uppercase">Add New User</h3>
                            <p className="text-xs text-zinc-500 mt-1">Pre-register a user and assign their role</p>
                          </div>
                          <button 
                            type="button"
                            onClick={() => setShowAddUserModal(false)}
                            className="p-2 hover:bg-zinc-100 rounded-full transition-colors"
                          >
                            <XCircle size={24} className="text-zinc-400" />
                          </button>
                        </div>

                        <div className="space-y-4">
                          <div className="space-y-2">
                            <label className="text-[10px] font-bold text-zinc-400 uppercase tracking-widest">Full Name</label>
                            <input 
                              type="text" 
                              required
                              value={newUserName}
                              onChange={(e) => setNewUserName(e.target.value)}
                              placeholder="e.g. Rajesh Kumar"
                              className="w-full p-4 bg-zinc-50 border border-zinc-200 rounded-xl text-xs focus:outline-none focus:ring-2 focus:ring-rose-500/20"
                            />
                          </div>
                          <div className="space-y-2">
                            <label className="text-[10px] font-bold text-zinc-400 uppercase tracking-widest">Email Address</label>
                            <input 
                              type="email" 
                              required
                              value={newUserEmail}
                              onChange={(e) => setNewUserEmail(e.target.value)}
                              placeholder="e.g. rajesh@indiapost.gov.in"
                              className="w-full p-4 bg-zinc-50 border border-zinc-200 rounded-xl text-xs focus:outline-none focus:ring-2 focus:ring-rose-500/20"
                            />
                          </div>
                          <div className="space-y-2">
                            <label className="text-[10px] font-bold text-zinc-400 uppercase tracking-widest">Assign Role</label>
                            <select 
                              value={newUserRole}
                              onChange={(e) => setNewUserRole(e.target.value as any)}
                              className="w-full p-4 bg-zinc-50 border border-zinc-200 rounded-xl text-xs focus:outline-none focus:ring-2 focus:ring-rose-500/20 font-bold"
                            >
                              <option value="user">Public User</option>
                              <option value="worker">Audit Worker</option>
                              <option value="admin">Administrator</option>
                            </select>
                          </div>
                        </div>

                        <button 
                          type="submit"
                          className="w-full py-4 bg-rose-600 text-white rounded-2xl font-bold flex items-center justify-center gap-2 hover:bg-rose-500 transition-all shadow-lg shadow-rose-200"
                        >
                          <UserPlus size={18} /> CREATE USER PROFILE
                        </button>
                      </form>
                    </motion.div>
                  </div>
                )}
              </AnimatePresence>

              <div className="bg-white rounded-3xl border border-zinc-200 shadow-sm overflow-hidden">
                <div className="overflow-x-auto">
                  <table className="w-full text-left border-collapse">
                    <thead>
                      <tr className="bg-zinc-50/50">
                        <th className="px-6 py-4 text-[10px] font-bold text-zinc-400 uppercase tracking-widest">User</th>
                        <th className="px-6 py-4 text-[10px] font-bold text-zinc-400 uppercase tracking-widest">Email</th>
                        <th className="px-6 py-4 text-[10px] font-bold text-zinc-400 uppercase tracking-widest">Role</th>
                        <th className="px-6 py-4 text-[10px] font-bold text-zinc-400 uppercase tracking-widest">Joined</th>
                        <th className="px-6 py-4 text-[10px] font-bold text-zinc-400 uppercase tracking-widest text-right">Actions</th>
                      </tr>
                    </thead>
                    <tbody className="divide-y divide-zinc-100">
                      {allUsers.map((u) => (
                        <tr key={u.id} className="hover:bg-zinc-50/50 transition-colors">
                          <td className="px-6 py-4">
                            <div className="flex items-center gap-3">
                              <div className="w-8 h-8 rounded-full bg-zinc-100 overflow-hidden border border-zinc-200">
                                {u.photoURL ? <img src={u.photoURL} alt="" /> : <div className="w-full h-full flex items-center justify-center text-[10px] font-bold text-zinc-400">{u.displayName?.charAt(0)}</div>}
                              </div>
                              <span className="text-xs font-bold">{u.displayName || 'Anonymous'}</span>
                            </div>
                          </td>
                          <td className="px-6 py-4 text-xs text-zinc-500 font-medium">
                            <div className="flex items-center gap-2">
                              <Mail size={12} className="text-zinc-300" />
                              {u.email}
                            </div>
                          </td>
                          <td className="px-6 py-4">
                            <div className="flex items-center gap-2">
                              <select 
                                value={u.role}
                                onChange={(e) => updateUserRole(u.id, e.target.value as any)}
                                className={`text-[10px] font-bold px-2 py-1 rounded-lg border focus:outline-none focus:ring-2 focus:ring-rose-500/20 ${
                                  u.role === 'admin' ? 'bg-rose-50 text-rose-600 border-rose-100' :
                                  u.role === 'worker' ? 'bg-blue-50 text-blue-600 border-blue-100' :
                                  'bg-zinc-50 text-zinc-600 border-zinc-100'
                                }`}
                              >
                                <option value="user">Public User</option>
                                <option value="worker">Audit Worker</option>
                                <option value="admin">Administrator</option>
                              </select>
                            </div>
                          </td>
                          <td className="px-6 py-4 text-xs text-zinc-400 font-medium">
                            {u.createdAt?.toDate?.()?.toLocaleDateString() || 'Recently'}
                          </td>
                          <td className="px-6 py-4 text-right">
                            <button 
                              onClick={() => deleteUserAccount(u.id)}
                              disabled={u.uid === user.uid}
                              className={`p-2 rounded-lg transition-all ${u.uid === user.uid ? 'text-zinc-200' : 'text-zinc-400 hover:text-rose-600 hover:bg-rose-50'}`}
                              title={u.uid === user.uid ? "You cannot delete your own account" : "Delete user profile"}
                            >
                              <UserMinus size={16} />
                            </button>
                          </td>
                        </tr>
                      ))}
                      {allUsers.length === 0 && !isUsersLoading && (
                        <tr>
                          <td colSpan={5} className="px-6 py-12 text-center text-zinc-400 text-sm italic">
                            No users found in the system.
                          </td>
                        </tr>
                      )}
                      {isUsersLoading && (
                        <tr>
                          <td colSpan={5} className="px-6 py-12 text-center">
                            <RefreshCw size={24} className="animate-spin text-rose-600 mx-auto" />
                          </td>
                        </tr>
                      )}
                    </tbody>
                  </table>
                </div>
              </div>

              <div className="bg-rose-50 border border-rose-100 rounded-3xl p-6 flex gap-4">
                <Shield size={24} className="text-rose-600 shrink-0" />
                <div className="space-y-1">
                  <h4 className="text-sm font-black text-rose-900 uppercase tracking-tight">Administrative Security Notice</h4>
                  <p className="text-xs text-rose-800 leading-relaxed">
                    Role changes take effect immediately. Administrators have full access to all audit data, analytics, and user profiles. 
                    Deleting a user profile removes their access and role data from Firestore, but does not delete their Google Auth account.
                  </p>
                </div>
              </div>
            </motion.div>
          ) : (
            <motion.div 
              key="audit"
              initial={{ opacity: 0, x: 20 }}
              animate={{ opacity: 1, x: 0 }}
              exit={{ opacity: 0, x: -20 }}
              className="grid grid-cols-1 lg:grid-cols-12 gap-8"
            >
              {/* Left Column: Upload & Preview */}
              <div className="lg:col-span-5 space-y-6">
                <section className="bg-white rounded-2xl border border-zinc-200 overflow-hidden shadow-sm">
                  <div className="p-4 border-b border-zinc-100 bg-zinc-50/50 flex justify-between items-center">
                    <div className="flex flex-col">
                      <h2 className="text-sm font-bold flex items-center gap-2">
                        <Camera size={16} className="text-zinc-400" />
                        AUDIT CAPTURE
                      </h2>
                      {(userProfile?.role === 'admin' || userProfile?.role === 'worker') && (
                        <button 
                          onClick={() => {
                            setIsCleanupMode(!isCleanupMode);
                            reset();
                          }}
                          className={`text-[9px] font-black uppercase tracking-widest mt-1 px-2 py-0.5 rounded-full border transition-all ${
                            isCleanupMode 
                              ? 'bg-emerald-500 text-white border-emerald-400' 
                              : 'bg-zinc-100 text-zinc-400 border-zinc-200'
                          }`}
                        >
                          {isCleanupMode ? 'Cleanup Mode Active' : 'Enable Cleanup Mode'}
                        </button>
                      )}
                    </div>
                    <div className="flex items-center gap-2">
                      <select 
                        value={selectedLocation.id}
                        onChange={(e) => setSelectedLocation(filteredPostOffices.find(po => po.id === e.target.value)!)}
                        className="text-[10px] font-bold bg-white border border-zinc-200 rounded px-2 py-1 focus:outline-none focus:ring-2 focus:ring-rose-500/20"
                      >
                        {filteredPostOffices.map(po => (
                          <option key={po.id} value={po.id}>{po.name}</option>
                        ))}
                      </select>
                      {image && (
                        <button 
                          onClick={reset}
                          className="text-xs font-bold text-rose-600 hover:bg-rose-50 px-2 py-1 rounded transition-colors"
                        >
                          RESET
                        </button>
                      )}
                    </div>
                  </div>
                  
                  <div className="p-6">
                    {isCleanupMode && (userProfile?.role === 'admin' || userProfile?.role === 'worker') ? (
                      <div className="space-y-6">
                        <div className="grid grid-cols-2 gap-4">
                          <div className="space-y-2">
                            <p className="text-[10px] font-bold text-zinc-400 uppercase tracking-widest">Before Cleanup</p>
                            {!beforeImage ? (
                              <div 
                                onClick={() => {
                                  const input = document.createElement('input');
                                  input.type = 'file';
                                  input.accept = 'image/*';
                                  input.onchange = (e: any) => {
                                    const file = e.target.files?.[0];
                                    if (file) {
                                      const reader = new FileReader();
                                      reader.onload = async (e) => {
                                        const resized = await resizeImage(e.target?.result as string);
                                        setBeforeImage(resized);
                                      };
                                      reader.readAsDataURL(file);
                                    }
                                  };
                                  input.click();
                                }}
                                className="aspect-square rounded-xl border-2 border-dashed border-zinc-200 flex flex-col items-center justify-center gap-2 cursor-pointer hover:border-rose-300 hover:bg-rose-50/30 transition-all group"
                              >
                                <Upload size={20} className="text-zinc-400 group-hover:scale-110 transition-transform" />
                                <span className="text-[8px] font-bold text-zinc-500">UPLOAD BEFORE</span>
                              </div>
                            ) : (
                              <div className="relative aspect-square rounded-xl overflow-hidden border border-zinc-200">
                                <img src={beforeImage} alt="Before" className="w-full h-full object-cover" referrerPolicy="no-referrer" />
                                <button 
                                  onClick={() => setBeforeImage(null)}
                                  className="absolute top-1 right-1 p-1 bg-white/80 rounded-full shadow-sm"
                                >
                                  <XCircle size={12} className="text-rose-600" />
                                </button>
                              </div>
                            )}
                          </div>
                          <div className="space-y-2">
                            <p className="text-[10px] font-bold text-zinc-400 uppercase tracking-widest">After Cleanup</p>
                            {!image ? (
                              <div 
                                onClick={() => {
                                  const input = document.createElement('input');
                                  input.type = 'file';
                                  input.accept = 'image/*';
                                  input.onchange = (e: any) => {
                                    const file = e.target.files?.[0];
                                    if (file) {
                                      const reader = new FileReader();
                                      reader.onload = async (e) => {
                                        const resized = await resizeImage(e.target?.result as string);
                                        setImage(resized);
                                      };
                                      reader.readAsDataURL(file);
                                    }
                                  };
                                  input.click();
                                }}
                                className="aspect-square rounded-xl border-2 border-dashed border-zinc-200 flex flex-col items-center justify-center gap-2 cursor-pointer hover:border-emerald-300 hover:bg-emerald-50/30 transition-all group"
                              >
                                <Upload size={20} className="text-zinc-400 group-hover:scale-110 transition-transform" />
                                <span className="text-[8px] font-bold text-zinc-500">UPLOAD AFTER</span>
                              </div>
                            ) : (
                              <div className="relative aspect-square rounded-xl overflow-hidden border border-emerald-200">
                                <img src={image} alt="After" className="w-full h-full object-cover" referrerPolicy="no-referrer" />
                                <button 
                                  onClick={() => setImage(null)}
                                  className="absolute top-1 right-1 p-1 bg-white/80 rounded-full shadow-sm"
                                >
                                  <XCircle size={12} className="text-rose-600" />
                                </button>
                              </div>
                            )}
                          </div>
                        </div>

                        <button 
                          onClick={logManualCleanup}
                          disabled={!beforeImage || !image || isLoggingCleanup}
                          className="w-full py-4 bg-emerald-600 text-white rounded-xl font-bold flex items-center justify-center gap-2 hover:bg-emerald-500 transition-all shadow-lg shadow-emerald-100 disabled:opacity-50"
                        >
                          {isLoggingCleanup ? <RefreshCw size={18} className="animate-spin" /> : <ShieldCheck size={18} />}
                          LOG ESG CLEANUP EVIDENCE
                        </button>
                      </div>
                    ) : !image ? (
                      <div 
                        onClick={() => fileInputRef.current?.click()}
                        className="aspect-square rounded-xl border-2 border-dashed border-zinc-200 flex flex-col items-center justify-center gap-4 cursor-pointer hover:border-rose-300 hover:bg-rose-50/30 transition-all group"
                      >
                        <div className="w-16 h-16 bg-zinc-100 rounded-full flex items-center justify-center text-zinc-400 group-hover:scale-110 transition-transform">
                          <Upload size={32} />
                        </div>
                        <div className="text-center">
                          <p className="font-bold text-zinc-700">Upload {selectedLocation.name} Feed</p>
                          <p className="text-xs text-zinc-500 mt-1">PNG, JPG up to 10MB</p>
                        </div>
                        <input 
                          type="file" 
                          ref={fileInputRef} 
                          onChange={handleImageUpload} 
                          accept="image/*" 
                          className="hidden" 
                        />
                      </div>
                    ) : (
                      <div className="space-y-4">
                        <div className="relative aspect-square rounded-xl overflow-hidden border border-zinc-200 shadow-inner bg-zinc-100">
                          <img 
                            src={image} 
                            alt="Preview" 
                            className="w-full h-full object-cover"
                            referrerPolicy="no-referrer"
                          />
                          {isAnalyzing && (
                            <div className="absolute inset-0 bg-black/40 backdrop-blur-sm flex flex-col items-center justify-center text-white p-6 text-center">
                              <RefreshCw size={40} className="animate-spin mb-4" />
                              <p className="font-bold">Analyzing {selectedLocation.name}...</p>
                              <p className="text-xs opacity-70 mt-2">Verifying architectural authenticity for {selectedLocation.area}</p>
                            </div>
                          )}
                        </div>
                        
                        {!result && !isAnalyzing && (
                          <div className="space-y-4">
                            {userProfile?.role === 'user' && (
                              <div className="space-y-2">
                                <label className="text-[10px] font-bold text-zinc-400 uppercase tracking-widest">Complaint Description</label>
                                <textarea 
                                  value={complaintDescription}
                                  onChange={(e) => setComplaintDescription(e.target.value)}
                                  placeholder="Describe the issue (e.g., litter near counter 2, overflowing bin...)"
                                  className="w-full p-4 bg-zinc-50 border border-zinc-200 rounded-xl text-xs focus:outline-none focus:ring-2 focus:ring-rose-500/20 min-h-[100px] resize-none"
                                />
                              </div>
                            )}

                            <div className="flex gap-3">
                              {(userProfile?.role === 'admin' || userProfile?.role === 'worker') && (
                                <button 
                                  onClick={startAnalysis}
                                  className="flex-1 py-4 bg-zinc-900 text-white rounded-xl font-bold flex items-center justify-center gap-2 hover:bg-zinc-800 transition-colors shadow-lg shadow-zinc-200"
                                >
                                  RUN AI AUDIT <ChevronRight size={18} />
                                </button>
                              )}
                              {userProfile?.role === 'user' && (
                                <button 
                                  onClick={submitComplaint}
                                  disabled={isSubmittingComplaint}
                                  className="flex-1 py-4 bg-rose-600 text-white rounded-xl font-bold flex items-center justify-center gap-2 hover:bg-rose-500 transition-colors shadow-lg shadow-rose-200 disabled:opacity-50"
                                >
                                  {isSubmittingComplaint ? <RefreshCw size={18} className="animate-spin" /> : <Send size={18} />}
                                  SUBMIT COMPLAINT
                                </button>
                              )}
                            </div>
                          </div>
                        )}
                      </div>
                    )}

                    {error && (
                      <div className="mt-4 p-3 bg-rose-50 border border-rose-100 rounded-lg flex items-start gap-3 text-rose-700 text-sm">
                        <AlertTriangle size={18} className="shrink-0 mt-0.5" />
                        <p>{error}</p>
                      </div>
                    )}
                  </div>
                </section>

                <section className="p-4 bg-amber-50 border border-amber-100 rounded-xl flex gap-4">
                  <Info size={20} className="text-amber-600 shrink-0" />
                  <div className="text-xs text-amber-800 leading-relaxed">
                    <p className="font-bold mb-1">Audit Guidelines for {selectedLocation.name}:</p>
                    <ul className="list-disc ml-4 space-y-1">
                      <li>Ensure clear visibility of floors and counters.</li>
                      <li>Include architectural features for location verification.</li>
                      <li>Avoid blurry or low-light captures.</li>
                    </ul>
                  </div>
                </section>
              </div>

              {/* Right Column: Results */}
              <div className="lg:col-span-7">
                <AnimatePresence mode="wait">
                  {!result ? (
                    <motion.div 
                      initial={{ opacity: 0, y: 10 }}
                      animate={{ opacity: 1, y: 0 }}
                      exit={{ opacity: 0, y: -10 }}
                      className="h-full flex flex-col items-center justify-center text-center p-12 border-2 border-dashed border-zinc-200 rounded-3xl"
                    >
                      <div className="w-20 h-20 bg-zinc-100 rounded-full flex items-center justify-center text-zinc-300 mb-6">
                        <CheckCircle2 size={48} />
                      </div>
                      <h3 className="text-xl font-bold text-zinc-400">Awaiting {selectedLocation.name} Data</h3>
                      <p className="text-sm text-zinc-500 mt-2 max-w-xs">
                        Upload an image of the post office premises to begin the automated cleanliness inspection.
                      </p>
                    </motion.div>
                  ) : (
                    <motion.div 
                      initial={{ opacity: 0, scale: 0.98 }}
                      animate={{ opacity: 1, scale: 1 }}
                      className="space-y-6"
                    >
                      {/* Score Card */}
                      <div className="bg-white p-8 rounded-3xl border border-zinc-200 shadow-sm flex flex-col md:flex-row items-center gap-8">
                        <div className="relative">
                          <svg className="w-32 h-32 transform -rotate-90">
                            <circle
                              cx="64"
                              cy="64"
                              r="58"
                              stroke="currentColor"
                              strokeWidth="8"
                              fill="transparent"
                              className="text-zinc-100"
                            />
                            <circle
                              cx="64"
                              cy="64"
                              r="58"
                              stroke="currentColor"
                              strokeWidth="8"
                              fill="transparent"
                              strokeDasharray={364}
                              strokeDashoffset={364 - (364 * result.cleanlinessScore) / 5}
                              className={`${getScoreColor(result.cleanlinessScore)} transition-all duration-1000 ease-out`}
                            />
                          </svg>
                          <div className="absolute inset-0 flex flex-col items-center justify-center">
                            <span className={`text-4xl font-black ${getScoreColor(result.cleanlinessScore)}`}>
                              {result.cleanlinessScore}
                            </span>
                            <span className="text-[10px] font-bold text-zinc-400 uppercase tracking-widest">Score</span>
                          </div>
                        </div>
                        
                        <div className="flex-1 text-center md:text-left">
                          <div className="flex items-center justify-center md:justify-start gap-2 mb-2">
                            <h2 className="text-2xl font-black tracking-tight">Audit Summary</h2>
                            {result.cleanlinessScore >= 4 ? (
                              <span className="px-2 py-0.5 bg-emerald-100 text-emerald-700 text-[10px] font-bold rounded uppercase">Excellent</span>
                            ) : result.cleanlinessScore >= 2.5 ? (
                              <span className="px-2 py-0.5 bg-amber-100 text-amber-700 text-[10px] font-bold rounded uppercase">Needs Attention</span>
                            ) : (
                              <span className="px-2 py-0.5 bg-rose-100 text-rose-700 text-[10px] font-bold rounded uppercase">Critical</span>
                            )}
                          </div>
                          <p className="text-zinc-600 text-sm leading-relaxed">{result.summary}</p>
                        </div>
                      </div>

                      {/* Verification & Details Grid */}
                      <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                        {/* Location Verification */}
                        <div className="bg-white p-6 rounded-2xl border border-zinc-200 shadow-sm">
                          <h3 className="text-xs font-bold text-zinc-400 uppercase tracking-widest mb-4 flex items-center gap-2">
                            <MapPin size={14} /> Location Verification
                          </h3>
                          <div className={`p-4 rounded-xl flex items-start gap-3 ${result.locationVerification.isAuthentic ? 'bg-emerald-50 border border-emerald-100' : 'bg-rose-50 border border-rose-100'}`}>
                            {result.locationVerification.isAuthentic ? (
                              <CheckCircle2 size={20} className="text-emerald-600 shrink-0" />
                            ) : (
                              <XCircle size={20} className="text-rose-600 shrink-0" />
                            )}
                            <div>
                              <p className={`font-bold text-sm ${result.locationVerification.isAuthentic ? 'text-emerald-900' : 'text-rose-900'}`}>
                                {result.locationVerification.isAuthentic ? `Authentic ${selectedLocation.name}` : 'Verification Failed'}
                              </p>
                              <p className="text-xs mt-1 opacity-80 leading-relaxed">
                                {result.locationVerification.reasoning}
                              </p>
                              <div className="mt-3 flex items-center gap-2">
                                <div className="flex-1 h-1 bg-zinc-200 rounded-full overflow-hidden">
                                  <div 
                                    className={`h-full ${result.locationVerification.isAuthentic ? 'bg-emerald-500' : 'bg-rose-500'}`}
                                    style={{ width: `${result.locationVerification.confidence * 100}%` }}
                                  />
                                </div>
                                <span className="text-[10px] font-bold opacity-60">{(result.locationVerification.confidence * 100).toFixed(0)}% Confidence</span>
                              </div>
                            </div>
                          </div>
                        </div>

                        {/* Detected Issues */}
                        <div className="bg-white p-6 rounded-2xl border border-zinc-200 shadow-sm">
                          <h3 className="text-xs font-bold text-zinc-400 uppercase tracking-widest mb-4 flex items-center gap-2">
                            <AlertTriangle size={14} /> Detected Issues
                          </h3>
                          <div className="space-y-3">
                            {result.detectedObjects.litter.length > 0 && (
                              <div className="flex items-start gap-2">
                                <Trash2 size={14} className="text-rose-500 mt-1" />
                                <div>
                                  <p className="text-xs font-bold text-zinc-700">Litter & Waste</p>
                                  <p className="text-[11px] text-zinc-500">{result.detectedObjects.litter.join(', ')}</p>
                                </div>
                              </div>
                            )}
                            {result.detectedObjects.infrastructureIssues.length > 0 && (
                              <div className="flex items-start gap-2">
                                <AlertTriangle size={14} className="text-amber-500 mt-1" />
                                <div>
                                  <p className="text-xs font-bold text-zinc-700">Infrastructure Stains</p>
                                  <p className="text-[11px] text-zinc-500">{result.detectedObjects.infrastructureIssues.join(', ')}</p>
                                </div>
                              </div>
                            )}
                            {result.detectedObjects.maintenanceIssues.length > 0 && (
                              <div className="flex items-start gap-2">
                                <RefreshCw size={14} className="text-zinc-400 mt-1" />
                                <div>
                                  <p className="text-xs font-bold text-zinc-700">Maintenance</p>
                                  <p className="text-[11px] text-zinc-500">{result.detectedObjects.maintenanceIssues.join(', ')}</p>
                                </div>
                              </div>
                            )}
                            {result.detectedObjects.litter.length === 0 && 
                             result.detectedObjects.infrastructureIssues.length === 0 && 
                             result.detectedObjects.maintenanceIssues.length === 0 && (
                              <p className="text-xs text-emerald-600 font-medium italic">No major issues detected.</p>
                            )}
                          </div>
                        </div>
                      </div>

                      {/* Recommendations */}
                      <div className="bg-zinc-900 text-white p-6 rounded-2xl shadow-xl">
                        <h3 className="text-xs font-bold text-zinc-400 uppercase tracking-widest mb-4 flex items-center gap-2">
                          <Star size={14} className="text-amber-400" /> Corrective Actions
                        </h3>
                        <ul className="grid grid-cols-1 md:grid-cols-2 gap-3">
                          {result.recommendations.map((rec, i) => (
                            <li key={i} className="flex items-start gap-3 text-xs text-zinc-300 bg-white/5 p-3 rounded-lg border border-white/10">
                              <span className="w-5 h-5 rounded-full bg-white/10 flex items-center justify-center text-[10px] font-bold shrink-0">{i + 1}</span>
                              {rec}
                            </li>
                          ))}
                        </ul>
                      </div>
                    </motion.div>
                  )}
                </AnimatePresence>
              </div>
            </motion.div>
          )}
        </AnimatePresence>
      </main>

      {/* Live Feed Modal */}
      <AnimatePresence>
        {viewingLiveFeed && (
          <div className="fixed inset-0 z-50 flex items-center justify-center p-4">
            <motion.div 
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              exit={{ opacity: 0 }}
              onClick={() => setViewingLiveFeed(null)}
              className="absolute inset-0 bg-black/80 backdrop-blur-sm"
            />
            <motion.div 
              initial={{ opacity: 0, scale: 0.9, y: 20 }}
              animate={{ opacity: 1, scale: 1, y: 0 }}
              exit={{ opacity: 0, scale: 0.9, y: 20 }}
              className="bg-white w-full max-w-3xl rounded-3xl overflow-hidden shadow-2xl relative z-10"
            >
              <div className="p-6 border-b border-zinc-100 flex items-center justify-between">
                <div>
                  <h2 className="text-lg font-black tracking-tight flex items-center gap-2">
                    <Activity size={20} className="text-rose-600" />
                    LIVE FEED: {filteredPostOffices.find(po => po.id === viewingLiveFeed)?.name}
                  </h2>
                  <p className="text-[10px] text-zinc-500 uppercase tracking-widest font-bold">{currentDivision.name} • Camera 01 • Secure Stream</p>
                </div>
                <button 
                  onClick={() => setViewingLiveFeed(null)}
                  className="w-10 h-10 rounded-full bg-zinc-100 flex items-center justify-center text-zinc-500 hover:bg-zinc-200 transition-colors"
                >
                  <XCircle size={20} />
                </button>
              </div>
              <div className="aspect-video bg-black relative group overflow-hidden">
                <img 
                  src={`https://picsum.photos/seed/live-${viewingLiveFeed}/1280/720`} 
                  alt="Live Feed" 
                  className={`w-full h-full object-cover transition-all duration-500 ${isFeedPaused ? 'opacity-40 grayscale blur-sm' : 'opacity-80'}`}
                  referrerPolicy="no-referrer"
                />

                {/* AI Detections Overlay */}
                {!isFeedPaused && liveDetections.map((detection) => (
                  <motion.div
                    key={detection.id}
                    initial={{ opacity: 0, scale: 0.8 }}
                    animate={{ opacity: 1, scale: 1 }}
                    exit={{ opacity: 0, scale: 0.8 }}
                    className={`absolute border-2 rounded-lg pointer-events-none flex flex-col items-start ${
                      detection.color === 'rose' ? 'border-rose-500' : 
                      detection.color === 'blue' ? 'border-blue-500' : 'border-amber-500'
                    }`}
                    style={{
                      left: `${detection.x}%`,
                      top: `${detection.y}%`,
                      width: `${detection.width}%`,
                      height: `${detection.height}%`
                    }}
                  >
                    <div className={`px-1.5 py-0.5 rounded-br-lg text-[8px] font-black text-white uppercase ${
                      detection.color === 'rose' ? 'bg-rose-500' : 
                      detection.color === 'blue' ? 'bg-blue-500' : 'bg-amber-500'
                    }`}>
                      {detection.label}
                    </div>
                  </motion.div>
                ))}

                {isAnalyzingAI && (
                  <div className="absolute inset-0 pointer-events-none">
                    <motion.div 
                      initial={{ top: '0%' }}
                      animate={{ top: '100%' }}
                      transition={{ duration: 2, repeat: Infinity, ease: "linear" }}
                      className="absolute left-0 right-0 h-0.5 bg-rose-500 shadow-[0_0_15px_rgba(244,63,94,0.8)] z-20"
                    />
                    <div className="absolute inset-0 bg-rose-500/5 animate-pulse" />
                  </div>
                )}
                
                {isFeedPaused && (
                  <div className="absolute inset-0 flex items-center justify-center">
                    <div className="bg-white/10 backdrop-blur-md p-4 rounded-full text-white">
                      <Pause size={48} fill="currentColor" />
                    </div>
                  </div>
                )}

                <div className="absolute top-4 left-4 flex items-center gap-2">
                  <div className={`flex items-center gap-2 px-3 py-1 rounded-full text-[10px] font-black transition-colors ${isFeedPaused ? 'bg-zinc-600 text-zinc-300' : 'bg-rose-600 text-white animate-pulse'}`}>
                    <div className={`w-1.5 h-1.5 rounded-full ${isFeedPaused ? 'bg-zinc-400' : 'bg-white'}`}></div> 
                    {isFeedPaused ? 'PAUSED' : 'LIVE'}
                  </div>
                  <div className="bg-black/40 backdrop-blur-md text-white px-2 py-1 rounded text-[10px] font-bold flex items-center gap-1.5">
                    <Settings2 size={10} /> {feedQuality}
                  </div>
                </div>

                <div className="absolute top-4 right-4 text-white/70 text-[10px] font-mono bg-black/40 px-2 py-1 rounded backdrop-blur-md">
                  {new Date().toISOString()}
                </div>

                <div className="absolute bottom-0 inset-x-0 p-6 bg-gradient-to-t from-black/90 via-black/20 to-transparent">
                  <div className="flex items-center justify-between">
                    <div className="flex items-center gap-4">
                      <div className="flex flex-col items-center gap-1">
                        <button 
                          onClick={() => setIsFeedPaused(!isFeedPaused)}
                          className={`w-12 h-12 rounded-full flex items-center justify-center transition-all shadow-xl ${isFeedPaused ? 'bg-rose-600 text-white animate-pulse' : 'bg-white text-zinc-900 hover:scale-110'}`}
                        >
                          {isFeedPaused ? <Play size={20} fill="currentColor" /> : <Pause size={20} fill="currentColor" />}
                        </button>
                        <span className="text-[8px] font-black text-white/60 uppercase tracking-widest">{isFeedPaused ? 'RESUME' : 'PAUSE'}</span>
                      </div>
                      
                      <div className="h-10 w-px bg-white/20"></div>
                      
                      <div className="space-y-1">
                        <span className="text-[8px] font-black text-white/60 uppercase tracking-widest ml-1">Stream Quality</span>
                        <div className="flex items-center bg-black/40 backdrop-blur-md rounded-xl p-1 border border-white/10">
                          {(['720p', '1080p', '4K'] as const).map((q) => (
                            <button
                              key={q}
                              onClick={() => setFeedQuality(q)}
                              className={`px-3 py-1.5 rounded-lg text-[10px] font-black transition-all ${feedQuality === q ? 'bg-white text-zinc-900 shadow-lg' : 'text-white/60 hover:text-white'}`}
                            >
                              {q}
                            </button>
                          ))}
                        </div>
                      </div>
                    </div>

                    <div className="flex items-center gap-3">
                      <button 
                        onClick={() => {
                          setSelectedLocation(filteredPostOffices.find(po => po.id === viewingLiveFeed)!);
                          setViewingLiveFeed(null);
                          setActiveTab('audit');
                        }}
                        className="px-6 py-2.5 bg-rose-600 text-white rounded-xl text-[10px] font-black uppercase tracking-widest hover:bg-rose-500 transition-all shadow-lg shadow-rose-900/20"
                      >
                        TRIGGER MANUAL AUDIT
                      </button>
                      {(userProfile?.role === 'admin' || userProfile?.role === 'worker') && (
                        <button 
                          onClick={() => triggerAIScan(viewingLiveFeed!)}
                          disabled={isAnalyzingAI}
                          className="px-6 py-2.5 bg-zinc-900 text-white rounded-xl text-[10px] font-black uppercase tracking-widest hover:bg-zinc-800 transition-all shadow-lg flex items-center gap-2 disabled:opacity-50"
                        >
                          {isAnalyzingAI ? <RefreshCw size={14} className="animate-spin" /> : <Sparkles size={14} />}
                          RUN AI DIAGNOSTICS
                        </button>
                      )}
                    </div>
                  </div>
                </div>
              </div>
            </motion.div>
          </div>
        )}
      </AnimatePresence>

      <footer className="max-w-6xl mx-auto px-4 py-12 border-t border-zinc-200 mt-12">
        <div className="flex flex-col md:flex-row justify-between items-center gap-6 opacity-50 grayscale">
          <div className="flex items-center gap-4">
            <img src="https://upload.wikimedia.org/wikipedia/en/thumb/8/8c/India_Post_Logo.svg/1200px-India_Post_Logo.svg.png" alt="India Post" className="h-8 object-contain" referrerPolicy="no-referrer" />
            <div className="h-8 w-px bg-zinc-300"></div>
            <p className="text-[10px] font-bold uppercase tracking-tighter">Swachh Bharat Mission</p>
          </div>
          <p className="text-[10px] font-medium">© 2026 Department of Posts • {currentDivision.name} • AI Audit System</p>
        </div>
      </footer>

      {/* Settings Modal */}
      <AnimatePresence>
        {showSettings && (
          <div className="fixed inset-0 z-[100] flex items-center justify-center p-4 bg-black/60 backdrop-blur-sm">
            <motion.div 
              initial={{ opacity: 0, scale: 0.9 }}
              animate={{ opacity: 1, scale: 1 }}
              exit={{ opacity: 0, scale: 0.9 }}
              className="bg-white w-full max-w-md rounded-[32px] overflow-hidden shadow-2xl"
            >
              <div className="p-8 space-y-8">
                <div className="flex items-center justify-between">
                  <div className="space-y-1">
                    <h2 className="text-2xl font-black tracking-tight uppercase">Settings</h2>
                    <p className="text-xs text-zinc-500 font-medium">Customize your experience</p>
                  </div>
                  <button onClick={() => setShowSettings(false)} className="p-2 hover:bg-zinc-100 rounded-full transition-colors">
                    <X size={24} />
                  </button>
                </div>

                <div className="space-y-6">
                  <div className="space-y-4">
                    <h3 className="text-[10px] font-black text-zinc-400 uppercase tracking-widest">Notification Preferences</h3>
                    <div className="space-y-3">
                      {[
                        { id: 'garbage', label: 'AI Garbage Detection', icon: Trash },
                        { id: 'water', label: 'AI Saturated Water', icon: Droplets },
                        { id: 'overflow', label: 'AI Bins Overflowing', icon: Trash2 },
                        { id: 'complaints', label: 'New Citizen Complaints', icon: MessageSquare },
                      ].map((pref) => {
                        const isEnabled = userProfile?.notificationPreferences?.[pref.id] !== false;
                        return (
                          <div key={pref.id} className="flex items-center justify-between p-4 bg-zinc-50 rounded-2xl border border-zinc-100">
                            <div className="flex items-center gap-3">
                              <div className="w-8 h-8 bg-white rounded-lg flex items-center justify-center text-zinc-600 shadow-sm">
                                <pref.icon size={16} />
                              </div>
                              <span className="text-xs font-bold text-zinc-700">{pref.label}</span>
                            </div>
                            <button 
                              onClick={() => {
                                const currentPrefs = userProfile?.notificationPreferences || { garbage: true, water: true, overflow: true, complaints: true };
                                updateNotificationPreferences({ ...currentPrefs, [pref.id]: !isEnabled });
                              }}
                              className={`w-12 h-6 rounded-full transition-all relative ${isEnabled ? 'bg-rose-600' : 'bg-zinc-300'}`}
                            >
                              <div className={`absolute top-1 w-4 h-4 bg-white rounded-full transition-all ${isEnabled ? 'left-7' : 'left-1'}`} />
                            </button>
                          </div>
                        );
                      })}
                    </div>
                  </div>
                </div>

                <button 
                  onClick={() => setShowSettings(false)}
                  className="w-full py-4 bg-zinc-900 text-white rounded-2xl font-black uppercase tracking-widest hover:bg-zinc-800 transition-all shadow-lg"
                >
                  Close Settings
                </button>
              </div>
            </motion.div>
          </div>
        )}
      </AnimatePresence>
      </div>
    </ErrorBoundary>
  );
}
