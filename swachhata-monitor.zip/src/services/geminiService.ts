import { GoogleGenAI, Type } from "@google/genai";

const ai = new GoogleGenAI({ apiKey: process.env.GEMINI_API_KEY || "" });

export interface AuditResult {
  cleanlinessScore: number;
  detectedObjects: {
    litter: string[];
    infrastructureIssues: string[];
    maintenanceIssues: string[];
  };
  locationVerification: {
    isAuthentic: boolean;
    confidence: number;
    reasoning: string;
  };
  summary: string;
  recommendations: string[];
}

export async function analyzePostOfficeImage(base64Image: string): Promise<AuditResult> {
  const model = "gemini-3-flash-preview";
  
  const prompt = `
    Analyze this image of an India Post office, specifically looking for cleanliness and infrastructure issues as per "Swachhata" standards.
    
    1. Identify Objects: Detect litter (plastic, paper, gutka wrappers), overflowing bins/dustbins, dusty counters, or cobwebs.
    2. Infrastructure Check: Identify "Yellow Spots" (urination marks), stained walls (betel leaf/paan stains), or broken furniture.
    3. Contextual Rating: Assign a Cleanliness Score (1–5) where 5 is perfectly clean.
    4. Location Verification: Check if the background matches the architectural style of Amravati's heritage or modern post office buildings (red brick, colonial arches, or standard India Post blue/red branding).
    
    Return the analysis in the following JSON format:
    {
      "cleanlinessScore": number,
      "detectedObjects": {
        "litter": ["item1", "item2"],
        "infrastructureIssues": ["issue1", "issue2"],
        "maintenanceIssues": ["issue1", "issue2", "bins overflowing"]
      },
      "locationVerification": {
        "isAuthentic": boolean,
        "confidence": number (0-1),
        "reasoning": "string"
      },
      "summary": "string",
      "recommendations": ["string"]
    }
  `;

  const response = await ai.models.generateContent({
    model,
    contents: [
      {
        parts: [
          { text: prompt },
          {
            inlineData: {
              mimeType: "image/jpeg",
              data: base64Image.split(",")[1] || base64Image,
            },
          },
        ],
      },
    ],
    config: {
      responseMimeType: "application/json",
    },
  });

  const text = response.text;
  if (!text) throw new Error("No response from AI");
  
  try {
    return JSON.parse(text) as AuditResult;
  } catch (e) {
    console.error("Failed to parse AI response:", text);
    throw new Error("Invalid response format from AI");
  }
}
